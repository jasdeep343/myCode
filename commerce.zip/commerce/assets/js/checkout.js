function checkEmail(){
	var email = $("#inputFN").val();
	if(email == ""){
		$( "#inputFN" ).focus();
		return false;	
	}
	$.ajax({
		url:"/demo/commerce/shoppingcart/checkUser",
		type:"POST",
		data: {'email':email },
		success:function(data){
			if(data == 1){
				$("#password_hidden").css('display','block');
				$("#confirm_password_hidden").css('display','none');
				var password = $("#password").val();
				if(password == ""){
					$( "#password" ).focus();
					return false;
				}else{
					$.ajax({
						url:"/demo/commerce/shoppingcart/login",
						type:"POST",
						data: {'email':email,'password':password },
						success:function(data){
								if(data == 1){
									location.reload();
								}else if(data == 0){
									alert("error login");
								}
							},
						error:function(data){
							console.error('Failed to process ajax !');
							}
						});
				}
			}else if (data == 0){
				$("#password_hidden").css('display','block');
				$("#confirm_password_hidden").css('display','block');
				
				var password = $("#password").val();
				var confirm_password = $("#confirm_password").val();
				if(password == ""){
					$( "#password" ).focus();
					return false;
				}else if(confirm_password == ""){
					$( "#confirm_password" ).focus();
					return false;
				}else if(password != confirm_password){
					alert("confirm password not matched");
				}else{
					$.ajax({
						url:"/demo/commerce/shoppingcart/signup",
						type:"POST",
						data: {'email':email,'password':password },
						success:function(data){
							alert(data);
								if(data == 1){
									location.reload();
								}else if(data == 0){
									alert("error login");
								}
						},
						error:function(data){
							alert(data);
						}
					});
				}
			}
		},
		error:function(data){
			console.error('Failed to process ajax !');
		}
	 });
}

$("#add_address").click(function(){
	var user_id = $("#user_id").val();
	var delivery_name = $("#delivery_name").val();
	var delivery_number = $("#delivery_number").val();
	var delivery_zipcode = $("#delivery_zipcode").val();
	var delivery_building_name = $("#delivery_building_name").val();
	var delivery_address = $("#delivery_address").val();
	var delivery_city = $("#delivery_city").val();
	var delivery_state = $("#delivery_state").val();
	var delivery_landmark = $("#delivery_landmark").val();
	
	var letters = /^[0-9]+$/;  //regex for alphanumeric values
	
	if(delivery_name == ""){
		$( "#delivery_name" ).focus();
		return false;	
	}else if(delivery_number == ""){
		$( "#delivery_number" ).focus();
		return false;	
	}else if (!delivery_number.match(letters)){
		alert('enter a valid numeric number');
		$( "#delivery_number" ).focus();
		return false;
	}else if (delivery_number.length > 10 || delivery_number.length < 10){
		alert('Enter a valid 10 digit number');
		$( "#delivery_number" ).focus();
		return false;
	}else if(delivery_zipcode == ""){
		$( "#delivery_zipcode" ).focus();
		return false;	
	}else if (!delivery_zipcode.match(letters)){
		alert('enter a valid numeric zipcode');
		$( "#delivery_zipcode" ).focus();
		return false;
	}else if (delivery_zipcode.length > 6 || delivery_zipcode.length < 6){
		alert('Enter a valid 6 zipcode');
		$( "#delivery_zipcode" ).focus();
		return false;
	}else if(delivery_building_name == ""){
		$( "#delivery_building_name" ).focus();
		return false;	
	}else if(delivery_address == ""){
		$( "#delivery_address" ).focus();
		return false;	
	}else if(delivery_city == ""){
		$( "#delivery_city" ).focus();
		return false;	
	}else if(delivery_state == ""){
		$( "#delivery_state" ).focus();
		return false;	
	}else if(delivery_landmark == ""){
		$( "#delivery_landmark" ).focus();
		return false;	
	}else{
		$.ajax({
			url:"/demo/commerce/shoppingcart/addAddress",
			type:"POST",
			data: {
				'user_id':user_id,
				'delivery_name':delivery_name,
				'delivery_number':delivery_number,
				'delivery_zipcode':delivery_zipcode,
				'delivery_building_name':delivery_building_name,
				'delivery_address':delivery_address,
				'delivery_city':delivery_city,
				'delivery_state':delivery_state,
				'delivery_landmark':delivery_landmark,
				},
			success:function(data){
					 if(data == 1){
						location.reload();
					}else if(data == 0){
						alert("error login");
					} /**/
			},
			error:function(data){
				alert(data);
			}
		});
	}
});

/* function showAddress(){
	$("#add_new_address").toggle();
} */

 $("#delivery_details").click(function(){
	var a = $("input[name=optradio]:checked").val();
	//console.log(typeof a); 
	if(a == undefined){
		$(".old-address").effect("shake");
	}else{
		$(".old-address").effect("bounce");
		$(".choose-address").fadeOut( "slow" );
		$("#delivery_address_id").fadeOut( "slow" );
		var order = $("#place_order").serialize();
		$.ajax({
			url:"/demo/commerce/shoppingcart/placeOrder",
			type:"POST",
			data: {
				'address_id':a,
				'product_info':order
			},
			success:function(data){
				alert(data);
					/* if(data == 1){
						location.reload();
					}else if(data == 0){
						alert("error login");
					} */
			},
			error:function(data){
				alert(data);
			}
		});
		/*$("#payment_option").fadeOut( "slow" );
		$("#address_id").val(a); */
		//$("#payment_option").css('display','block');
	}
});