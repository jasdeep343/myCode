function size_change(id){
	var url=window.location.host;
	$.ajax({
		url:"/demo/commerce/shoppingcart/getSize",
		type:"POST",
		data: {'id':id },
		success:function(data){
			var objData = jQuery.parseJSON(data);
			$("#formDropdown").empty();
			var option = document.createElement("option");	
			option.setAttribute("id","demoid");
			document.getElementById('formDropdown').appendChild(option);
			document.getElementById("demoid").innerHTML = "Select Size";
			 for(i=0;i<=objData.length;i++){
				var option = document.createElement("option");	
				option.setAttribute("id","demoid"+objData[i].id);
				document.getElementById('formDropdown').appendChild(option); 
				document.getElementById("demoid"+objData[i].id).innerHTML = objData[i].size;
			}
		},
		error:function(data){
			console.error('Failed to process ajax !');
		}
	 });
}

function changeProduct(id){
	$.ajax({
		url:"/demo/commerce/shoppingcart/getProduct",
		type:"POST",
		data: {'id':id },
		success:function(data){
			var objData = jQuery.parseJSON(data);
			$("#img_responsive").attr('src','/demo/commerce/assets/images/'+ objData.image);
			document.getElementById("amount").innerHTML = "$"+objData.price;
			document.getElementById("product_detail_id").value = objData.id;
			document.getElementById("product_price").value = objData.price;
			document.getElementById("product_img").value = objData.image;
			document.getElementById("Qty").innerHTML = "Total Quantity: "+objData.quantity;
		},
		error:function(data){
			console.error('Failed to process ajax !');
		}
	 });
}

$('#formDropdown').on('change', function() {
	//alert( this.value );
	$("#product_size").val(this.value);
})

$("#add_to_cart").click(function(){
	var product_size = $("#product_size").val();
	
	if(product_size == "" || product_size == "Select Size"){
		$( "#formDropdown" ).focus();
		return false;
	}
}); 
