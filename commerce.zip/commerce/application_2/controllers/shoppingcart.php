<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Shoppingcart extends CI_Controller {

	public function __construct(){
		parent::__construct();
		$this->load->model("product_model");
		$this->load->model("categories_model");
		$this->load->library('cart');
	}
	
	public function buy($id){
			$product = $this->product_model->find($id);
			$data = array(
				'id'      => $product->id,
				'qty'     => 1,
				'price'   => $product->price,
				'name'    => $product->product_name,
				'img'	  => $product->image_name
			);
			$this->cart->insert($data);
			$this->load->view('cart');
	}
	public function cart(){
		$this->load->view('cart');
	}
/* 	public function cart1(){
		$this->load->view('cart1');
	} */
	public function product_page($id){
		$val = ltrim($id,"id=");
		$data['product'] = $this->categories_model->find($val);
		//var_dump($product);die("fds");
		$this->load->view('single_page',$data);
	}
	/* Delete the product from cart*/
	public function delete($rowid){
		$this->cart->update(array('rowid'=>$rowid,'qty'=>0));
		$this->load->view('cart');
	}
	
	public function update(){
		$i = 1;
		foreach($this->cart->contents() as $items){
			$this->cart->update(array('rowid'=> $items['rowid'], 'qty'=>$_POST['qty'.$i]));
			$i++;
		}
		$this->load->view('cart');
	}
	/* Get the product by id's  of the product */
	public function search_product($id){
		$data['products'] = $this->product_model->product_byid($id);
		$this->load->view("product",$data);
	}
	
	/* serach the product by product name */
	public function search_ByName(){
		$name = trim($this->input->post('search'));
		$data['products'] = $this->categories_model->find_name($name);
		$this->load->view("product",$data);
	}
	
	
}
  
