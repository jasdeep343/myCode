<footer>
		<div id="copyright">
            <div class="container">
                <div class="footer_txt col-md-12">
					<ul>
						<li><a href="#">YOUR ACCOUNT</a></li>
						<li><a href="#">CONTACT US</a></li>
						<li><a href="#">TERMS OF SERVICE</a></li>
					</ul>
					<ul>
						<li><a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
						<li><a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
						<li><a href="#"><i class="fa fa-instagram" aria-hidden="true"></i></a></li>
						<li><a href="#"><i class="fa fa-pinterest-p" aria-hidden="true"></i></a></li>
					</ul>
                    <p>Copyright © 2016 Brand-Name. All Rights Reserved. Designed by Shuvo</p>
                </div>
            </div>
        </div>
	</footer>
	
    <!-- #### JAVASCRIPT FILES ### -->
    <script src="<?php echo base_url(); ?>assets/js/jquery-1.11.0.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/bootstrap.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/jquery.cookie.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/front.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/owl.carousel.min.js"></script>		<script src="<?php echo base_url(); ?>assets/js/prefixfree.js"></script>    <script src="<?php echo base_url(); ?>assets/js/min.js"></script>
</body>
</html>