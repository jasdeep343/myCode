<?php include('header.php'); ?>

	<section id="cart-section">
		<div class="cart-section">
			<div class="container">
				<div id="cartProductContainer">
				<?php echo form_open('shoppingcart/update'); ?>
					<div class="card">
						<!--div class="mess-container">
							<span class="circle"><i class="sd-icon fa fa-check"></i></span>
							<span class="mess-text">boAt BassHeads 200 In Ear Wired With Mic Earphones Blue added to your cart</span>
							<span class="sd-icon sd-icon-delete-sign close-mess"><i class="fa fa-times"></i></span> 
						</div-->
						<!--Order div Started-->
						<?php $i = 1; ?>
						<?php foreach ($this->cart->contents() as $items): ?>
						<?php echo form_hidden($i.'[rowid]', $items['rowid']); ?>
						<div class="cart-item-container row">
							<div class="col-xs-6 products">
								<div class="parent-product row">
									<div class="col-xs-3 reset-padding image-container">
										<a href="#" data-pog="651105915779" class="cart-link" target="_blank">
											<img class="img-size" src="<?php echo base_url();?>assets/images/<?php echo $items['img']; ?>">
										</a>
									</div>
									<div class="col-xs-9">
										<span class="product-name"><a href="#" class="cart-link" target="_blank">
										<?php echo $items['name']; ?>	
										<?php if ($this->cart->has_options($items['rowid']) == TRUE): ?>
											<p>	<?php foreach ($this->cart->product_options($items['rowid']) as $option_name => $option_value): ?>
												<strong><?php echo $option_name; ?>:</strong> <?php echo $option_value; ?><br />
												<?php endforeach; ?>
											</p>
										<?php endif; ?></a></span>
										<span class="price">Rs. <?php echo $this->cart->format_number($items['price']); ?></span>
									</div>
								</div>
							</div> 
							<div class="col-xs-6">
								<div class="action-container row">
									<div class="col-sm-6 info-container">
										<div class="cart">Your Order&nbsp;<?php echo form_input(array('class' => 'count','name' => 'qty'.$i, 'value' => $items['qty'], 'maxlength' => '3', 'size' => '5')); ?></div>
										<div class="you-pay">You Pay: <span class="price"><?php echo $this->cart->format_number($items['subtotal']); ?></span></div>
										<div class="extra-charges">(Including delivery and other charges. View Cart for details)</div>
									</div>
									<div class="col-sm-6 btn-container"><a class="btn marR5" href="<?php echo base_url()?>shoppingcart/delete/<?php echo $items['rowid'];?>">Remove</a><?php echo form_submit('', 'Update your Cart',"class='btn marR5'"); ?></div>
									
								</div>
							</div>
						</div>
						<?php $i++; ?>
						<?php endforeach; ?>
						<!--Order Div Ends-->
						<div class="col-sm-6 btn-container"><a href="#" class="btn marR5">Proceed To Checkout</a></div>
						<p>Total : <?php echo $this->cart->format_number($this->cart->total()); ?></p>
						
					</div>
					
					<!--p><?php echo anchor('index','< Continue Shopping');?> <?php echo form_submit('', 'Update your Cart'); ?></p-->
					<?php form_close();?>
				</div>
			</div>
		</div>
	</section>
<?php include('footer.php');?>