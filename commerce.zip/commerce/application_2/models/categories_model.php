<?php
class Categories_Model extends CI_Model{
	
	public function __construct() {
		parent::__construct();
	}
	
	function find_all(){
		return $this->db->get('products')->result();
	}
	
	function find($id){
		$this->db->where('id',$id);
		return $this->db->get('products')->row();
	}
	function find_name($name){
		$this->db->select("*");
		$this->db->from("products");
		$this->db->like('product_name', $name);
		$query=$this->db->get();
		return $query->result();
	}
	/* Data for mens menus */
	function mens_clothing(){
		$this->db->where(array('gender'=>1,'status'=>1,'type'=>1));
		return $this->db->get('category')->result();
	}
	
	function mens_footwear(){
		$this->db->where(array('gender'=>1,'status'=>1,'type'=>2));
		return $this->db->get('category')->result();
	}
	
	function mens_watches(){
		$this->db->where(array('gender'=>1,'status'=>1,'type'=>3));
		return $this->db->get('category')->result();
	}
	
	function mens_accessories(){
		$this->db->where(array('gender'=>1,'status'=>1,'type'=>4));
		return $this->db->get('category')->result();
	}
	
	function mens_personalcare(){
		$this->db->where(array('gender'=>1,'status'=>1,'type'=>5));
		return $this->db->get('category')->result();
	}
	
	function mens_grooming(){
		$this->db->where(array('gender'=>1,'status'=>1,'type'=>6));
		return $this->db->get('category')->result();
	}
	
	function get_categories($id){
		//$this->db->select("*");
		$this->db->where('id',$id);
		return $this->db->get('category')->row();
	}
	
	function womens_categories(){
		$this->db->select('*');
		$this->db->from('category');
		$this->db->where(array('gender'=>1,'status'=>1,'type'=>2));
		$query = $this->db->get();
		return $query->result();
	}
}
?>
