<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class index extends CI_Controller {
	public function __construct(){
		parent::__construct();
		$this->load->model("product_model");
		$this->load->model("categories_model");
		$this->load->library('cart');	
	}
	
	#throw the product data at the index table
	public function index($index = 0){
		$data['products'] = $this->product_model->find_all();
		$this->load->view("index",$data);
	}
}
  
