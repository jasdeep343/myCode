<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Shoppingcart extends CI_Controller {

	public function __construct(){
		parent::__construct();
		$this->load->model("product_model");
		$this->load->model("categories_model");
		$this->load->library('cart','session');
	}
	
	#in used
	public function buy(){
		$product_detail_id = $_GET['product_detail_id'];
		$getProduct = $this->categories_model->productDetailsById($product_detail_id);
		//var_dump($getProduct);die("GFd");
			$data = array(
				'id'      => $product_detail_id,
				'qty'     => 1,
				'price'   => $getProduct->price,
				'name'    => $_GET['product_name'],
				'options' => array('image' => $_GET['product_img'],'Size' => $_GET['product_size'], 'Color' => $_GET['product_detail_id'])
			);
			
		
			$this->cart->insert($data);
			$this->load->view('cart');
	}
	
	#in used
	public function cart(){
		$this->load->view('cart');
	}
	
	#in used
	public function product_page(){
		$val = $this->input->get('id');
		$data['product'] = $this->product_model->find($val);
		$this->load->view('single_page',$data);
	}
	
	#in used
	public function getSize(){
		$id = 	$this->input->post('id');
		$productSize = $this->categories_model->productSize($id);
		echo json_encode($productSize);
	}
	#in used
	public function getProduct(){
		$id = 	$this->input->post('id');
		$productDetailsById = $this->categories_model->productDetailsById($id);
		echo json_encode($productDetailsById);
	}
	
	/* Delete the product from cart*/		#in used
	public function delete($rowid){
		$this->cart->update(array('rowid'=>$rowid,'qty'=>0));
		$this->load->view('cart');
	}
	
	#in used
	public function update(){
		$i = 1;
		foreach($this->cart->contents() as $items){
			$this->cart->update(array('rowid'=> $items['rowid'], 'qty'=>$_POST['qty'.$i]));
			$i++;
		}
		$this->load->view('cart');
	}
	
	/* Get the product by id's  of the product */
 	public function search_product(){
		$id= $this->input->get('id');
		$data['products'] = $this->product_model->product_byid($id);
		//var_dump($data);die("Gf");
		$this->load->view("product",$data);
	}
	
	public function allProducts(){
		$data['products'] = $this->product_model->all();
		$this->load->view("product",$data);
	}
	
	/* serach the product by product name */
/* 	public function search_ByName(){
		$name = trim($this->input->post('search'));
		$data['products'] = $this->categories_model->find_name($name);
		$this->load->view("product",$data);
	} */
	
	#in used
	public function checkOut(){
		$this->load->view('checkout');	
	}
	
	/**/ public function viewLogin(){
		$this->load->view('checkout');	
	} 
	
	/**/ public function viewSignUp(){
		$this->load->view('checkout');	
	} 
	
	#in used
	public function checkUser(){
		$email = $this->input->post("email");
		$checkUserEmail = $this->product_model->checkUserEmail($email);
		if($checkUserEmail){
			echo "1";
		}else{
			echo "0";
		}
	}
	
	#in used
	public function login(){
		$arr['email'] = trim($this->input->post("email"));
		$arr['password'] = md5($this->input->post("password"));
		$getUserInfo = $this->product_model->getUserInfo($arr);
		$userdata = array(
			'user_id'=>$getUserInfo->id,
		); 
		
		$user_session = $this->session->set_userdata('user',$userdata);
		$userid = $this->session->userdata('user');
		if($userid){
			echo "1";
		}else{
			echo "0";
		}
	}
	
	#in used
	public function signup(){
		$arr['E_mail'] = trim($this->input->post("email"));
		$arr['P_wrd'] = md5($this->input->post("password"));
		$arr['P_image'] = "default.png";
		$arr['P_status'] = 1;
		$insertUser = $this->product_model->insertUser($arr);
		//var_dump($insertUser);die("sd");
		$userdata = array(
			'user_id'=>$insertUser,
		);
		$user_session = $this->session->set_userdata('user',$userdata);
		$userid = $this->session->userdata('user');
		if($userid){
			echo "1";
		}else{
			echo "0";
		}
	}
	
	#in used
	public function logout(){
		$this->session->unset_userdata('user');
		redirect(base_url(), 'refresh' );
	}
	
	#in used
	public function addAddress(){
		$arr['user_id'] = trim($this->input->post("user_id"));
		$arr['name'] = trim($this->input->post("delivery_name"));
		$arr['phone'] = trim($this->input->post("delivery_number"));
		$arr['pincode'] = trim($this->input->post("delivery_zipcode"));
		$arr['building_name'] = trim($this->input->post("delivery_building_name"));
		$arr['address'] = trim($this->input->post("delivery_address"));
		$arr['city'] = trim($this->input->post("delivery_city"));
		$arr['state'] = trim($this->input->post("delivery_state"));
		$arr['landmark'] = trim($this->input->post("delivery_landmark"));
		$arr['status'] = 1;
		
		 $insertUser = $this->product_model->insertAddress($arr);
		//var_dump($insertUser);die("insertUser");
		if($insertUser){
			echo "1";
		}else{
			echo "0";
		} 
	}
	
	public function placeOrder(){
		
		$userid = $this->session->userdata('user');
		$arr['address_id'] = trim($this->input->post("address_id"));
		$arr['user_id'] = $userid['user_id'];
		$contents = $this->cart->contents();
		foreach($contents as $content){
			$array = array(
				'user_id'=>$arr['user_id'],
				'product_id'=>1,
				'product_detail_id'=>$content['id'],
				'qty'=>$content['qty'],
				'price'=>$content['price'],
				'name'=>$content['name'],
				'address_id'=>$arr['address_id'],
				'size'=>$content['options']['Size'],
				'color_id'=>$content['options']['Color'],
				'status'=>0,
			);
			$placeOrder = $this->product_model->placeOrder($array);
			
		}
			if($placeOrder){
					echo "1";
					/* $productDetails = $this->categories_model->productDetails($content['id']);
					$arra['quantity'] = $productDetails->quantity - $content['qty'];
					$arra['id'] = $content['id'];
					var_dump($arra); */
					/* $productDetailsUpdate =	$this->categories_model->productDetailsUpdate($arra);
					if($productDetailsUpdate){
						echo "1";
					}else{
						echo "2";
					} */
			}else{
					echo "0";
			}
		
	}
	
}
  
