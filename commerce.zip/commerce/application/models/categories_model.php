<?php
class Categories_Model extends CI_Model{
	
	public function __construct() {
		parent::__construct();
	}
	
	
	/* function find_all(){
		return $this->db->get('products')->result();
	}
	
	function find($id){
		$this->db->where('id',$id);
		return $this->db->get('products')->row();
	} */
	
	#find the single product details by product id						user in index view
	function productDetails($id){
		$this->db->where('product_id',$id);
		return $this->db->get('product_detail')->row();
	}
	function productDetailsUpdate($array){
		$this->db->where('id',$array['id']);
		unset($array['id']);
		return $this->db->update('product_detail',$array);
	}
	
	#find the single product details by product id						user in index view
	function productDetailsData($id){
		$this->db->where('product_id',$id);
		return $this->db->get('product_detail')->result();
	}
	#find the single product details by product id						user in index view
	function productDetailsById($id){
		$this->db->where('id',$id);
		return $this->db->get('product_detail')->row();
	}
	
	#find the product size as per product detail id						user in index view
	function productSize($id){
		$this->db->where('detail_id',$id);
		return $this->db->get('tbl_size')->result();
	}
	
	function find_name($name){
		$this->db->select("*");
		$this->db->from("products");
		$this->db->like('product_name', $name);
		$query=$this->db->get();
		return $query->result();
	}
	/* Data for mens menus */
	function mens_clothing(){
		$this->db->where(array('gender'=>1,'status'=>1,'type'=>1));
		return $this->db->get('category')->result();
	}
	
	function mens_footwear(){
		$this->db->where(array('gender'=>1,'status'=>1,'type'=>2));
		return $this->db->get('category')->result();
	}
	
	function mens_watches(){
		$this->db->where(array('gender'=>1,'status'=>1,'type'=>3));
		return $this->db->get('category')->result();
	}
	
	function mens_accessories(){
		$this->db->where(array('gender'=>1,'status'=>1,'type'=>4));
		return $this->db->get('category')->result();
	}
	
	function mens_personalcare(){
		$this->db->where(array('gender'=>1,'status'=>1,'type'=>5));
		return $this->db->get('category')->result();
	}
	
	function mens_grooming(){
		$this->db->where(array('gender'=>1,'status'=>1,'type'=>6));
		return $this->db->get('category')->result();
	}
	
	function get_categories($id){
		//$this->db->select("*");
		$this->db->where('id',$id);
		return $this->db->get('category')->row();
	}
	
	/* get categories for womens*/
	function womens_westenwear(){
		$this->db->where(array('gender'=>2,'status'=>1,'type'=>7));
		return $this->db->get('category')->result();
	}

	function womens_winterwear(){
		$this->db->where(array('gender'=>2,'status'=>1,'type'=>8));
		return $this->db->get('category')->result();
	}

	function womens_ethnicwear(){	
		$this->db->where(array('gender'=>2,'status'=>1,'type'=>9));
		return $this->db->get('category')->result();
	}
	
	function womens_sleepwear(){
		$this->db->where(array('gender'=>2,'status'=>1,'type'=>10));
		return $this->db->get('category')->result();
	}

	function womens_footwear(){
		$this->db->where(array('gender'=>2,'status'=>1,'type'=>11));
		return $this->db->get('category')->result();
	}

	function womens_watches(){
		$this->db->where(array('gender'=>2,'status'=>1,'type'=>12));
		return $this->db->get('category')->result();
	}	
	
	function womens_personalcare(){
		$this->db->where(array('gender'=>2,'status'=>1,'type'=>13));
		return $this->db->get('category')->result();
	}
	function womens_beauty(){
		$this->db->where(array('gender'=>2,'status'=>1,'type'=>14));
		return $this->db->get('category')->result();
	}	
	
	function womens_accessories(){	
		$this->db->where(array('gender'=>2,'status'=>1,'type'=>15));
		return $this->db->get('category')->result();
	}

	function womens_jewellery(){
		$this->db->where(array('gender'=>2,'status'=>1,'type'=>16));
		return $this->db->get('category')->result();
	}
}
?>
