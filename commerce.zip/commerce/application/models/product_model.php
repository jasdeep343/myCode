<?php
class product_model extends CI_Model{
	public function __construct() {
		parent::__construct();
	}
	
	#Show all random product data to display
	function all(){
		return $this->db->get('products')->result();
	}
	
	#Product can be displayed with in limit with all specification
	function find_all(){
		$this->db->limit(12);
		return $this->db->get('products')->result();
	}
	
	#provide product details for single page
	function find($id){
		$this->db->where('id',$id);
		return $this->db->get('products')->row();
	}
	
	#provide product details for single page
	function product_byid($id){
		$this->db->where('cat_id',$id);
		return $this->db->get('products')->result();
	}
	
	function checkUserEmail($id){
		$this->db->where('E_mail',$id);
		return $this->db->get('_tbl_users')->num_rows();
	}
	
	function getUserInfo($arr){
		$this->db->where(array('E_mail'=>$arr['email'],'P_wrd'=>$arr['password']));
		return $this->db->get('_tbl_users')->row();
	}
	
	function getUserById($id){
		$this->db->select('id,F_name,L_name,E_mail,P_image')->where('id',$id);
		return $this->db->get('_tbl_users')->row();
	}
	
	function insertUser($array){
		$this->db->insert('_tbl_users',$array);
		return $this->db->insert_id();
	}
	
	function insertAddress($array){
		return $this->db->insert('tbl_delivery_address',$array);
	}
	
	function getAddress($id){
		$this->db->where('user_id',$id);
		return $this->db->get('tbl_delivery_address')->result();
	}
	
	function placeOrder($array){
		return $this->db->insert('_tbl_order',$array);
	}
	
	#get brand name by id
	function getBrandNameById($id){
		return $this->db->where('id',$id)->get('brand')->row();
	}
	
	#get all brands
	function getAllBrands(){
		return $this->db->get('brand')->result();
	}
}
?>
