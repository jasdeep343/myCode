<?php include('header.php'); ?>

	<!--div class="login-wrapper">
			<form id="form-login" role="form">
				<h4>Login</h4>
				<p>If you're a member, login here.</p>
				<div class="form-group">
					<label for="inputusername">Username</label>
					<input type="text" class="form-control input-lg" id="inputusername" placeholder="Username">
				</div>
				<div class="form-group">
					<label for="inputpassword">Password</label>
					<input type="password" class="form-control input-lg" id="inputpassword" placeholder="Password">
				</div>
				<ul class="list-inline">
					<li><a href="#">Create new account</a></li>
					<li><a href="#">Request new password</a></li>
				</ul>
				<button type="submit" class="btn btn-white">Log in</button>
			</form>
		</div-->
		<!-- End Login -->
		
		
		<!-- Begin Main -->
		<div role="main" class="main">
		
			<!-- Begin page top -->
			<section class="page-top">
				
			</section>
			<!-- End page top -->

			<div class="container">

				<div class="row featured-boxes">
					<div class="col-md-12">
						
						<div class="featured-box featured-box-secondary featured-box-cart">
							<?php
								if(empty($userid['user_id'])){
							?>
							<div class="box-content">
								<h4 style="text-align:center;margin-bottom: 15px;">Login or Signup</h4>
								<div class="form-horizontal">
									<div class="login_signup">
									<div class="boxes_login">
										<div class="form-group">
											<label for="inputFN" class="col-sm-2 control-label">Email<span class="required">*</span></label>
											<div class="col-sm-12">
												<input type="text" class="form-control" id="inputFN">
											</div>
										</div>
										<div class="form-group" id="password_hidden" style="display:none">
											<label for="password" class="col-sm-2 control-label">Password<span class="required">*</span></label>
											<div class="col-sm-12">
												<input type="password" class="form-control" id="password">
											</div>
										</div>
										<div class="form-group" id="confirm_password_hidden" style="display:none">
											<label for="confirm_password" class="col-sm-2 control-label">Confirm Password<span class="required">*</span></label>
											<div class="col-sm-12">
												<input type="password" class="form-control" id="confirm_password">
											</div>
										</div>
										<div class="form-group">
											<div class="col-sm-3">
												<input type="button" class="btn btn-primary btn-block btn-sm" id="place_order" value="CONTINUE" onClick="checkEmail()">
											</div>
										</div>								
									</div>								
									</div>								
								</div>
							</div>
							<?php }else{ ?>
							<?php	$getAddress = $this->product_model->getAddress($userid['user_id']); ?>
								<section class="choose-address">
									<h4 id="address_color">Select Address</h4>
									<div class="row">
									<?php foreach($getAddress as $address){?>
									<div class="old-address" id="old_address">
										<label class="choose">
											<input type="radio" class="gap-marge" id="selected_address" name="optradio" value="<?php echo $address->id; ?>"><?php echo $address->name; ?>, <?php echo $address->phone; ?>,<?php echo $address->address; ?>,<?php echo $address->building_name; ?>,<?php echo $address->city; ?>,<?php echo $address->state; ?>-<?php echo $address->pincode; ?>
											<span class="edit"><a href="#"><i class="fa fa-pencil-square-o"></i></a></span>
										</label>
									</div>
									<?php 	}	?>
									<div class="col-xs-12">
										<div class="address_form_group">
											<input type="button" class="btn btn-primary btn-block btn-sm" id="delivery_details" value="Deliver Here">
										</div>
									</div>
									</div>
								</section>
							<div class="box-content" id="delivery_address_id">
							
								<h4 id="address_color">Add new address</h4>
								<!-- Ids for all are same change them-->
								<div class="form-horizontal" id="add_new_address">
								<div class="row">
								<input type="hidden" id="user_id" value="<?php echo $userid['user_id']?>">
									<div class="col-sm-6">
										<label for="name" class="control-label">Name<span class="required">*</span></label>
										<div class="">
											<input type="text" class="form-control" id="delivery_name">
										</div>
									</div>
									<div class="col-sm-6">
										<label for="number" class="control-label">Phone<span class="required">*</span></label>
										<div class="">
											<input type="text" class="form-control" id="delivery_number" placeholder="Add numeric value">
										</div>
									</div>
									<div class="col-sm-6">
										<label for="zipcode" class="control-label">Zipcode<span class="required">*</span></label>
										<div class="">
											<input type="text" class="form-control" id="delivery_zipcode" placeholder="Add numeric value">
										</div>
									</div>
									<div class="col-sm-6">
										<label for="building_name" class="control-label">Building Name<span class="required">*</span></label>
										<div class="">
											<input type="text" class="form-control" id="delivery_building_name">
										</div>
									</div>
									<div class="col-sm-6">
										<label for="address" class="control-label">Address<span class="required">*</span></label>
										<div class="">
											<input type="text" class="form-control" id="delivery_address">
										</div>
									</div>
									<div class="col-sm-6">
										<label for="city" class="control-label">City<span class="required">*</span></label>
										<div class="">
											<input type="text" class="form-control" id="delivery_city">
										</div>
									</div>
									<div class="col-sm-6">
										<label for="state" class="control-label">State<span class="required">*</span></label>
										<div class="">
											<input type="text" class="form-control" id="delivery_state">
										</div>
									</div>
									<div class="col-sm-6">
										<label for="landmark" class="control-label">Landmark<span class="required">*</span></label>
										<div class="">
											<input type="text" class="form-control" id="delivery_landmark">
										</div>
									</div>
									<div class="col-sm-12">
										<div class="add_address_group">
											<input type="button" class="btn btn-primary btn-block btn-sm" id="add_address" value="Add Address">
										</div>
									</div>
								</div>
								</div>
							</div>
							<div id="payment_option" style="display:none">
								<div class="col-sm-12 gretting-design">
								<input type="hidden" value="" id="address_id">
								<input type="hidden" value="<?php echo $this->cart->format_number($this->cart->total()); ?>" name="">
							<!--	<h2>Payment option</h2>
								<label>COD
									<input type="checkbox" value="paypal" name="payment">
								</label>
								<label>Paypal
									<input type="checkbox" value="paypal" name="payment">
								</label>
								<label>Credit Card /Debit Card						
									<input type="checkbox" value="paypal" name="payment">
								</label> 
								</div>
							</div>
							<div style="display:none" id="gretting_design">
							<!--	<div class="col-sm-12 gretting-design">
									<img src="<?php echo base_url(); ?>assets/images/greeting_image2.png"/>
								</div>
								<a class="shopping-button" href="<?php echo base_url();?>">Continue Shopping</a>-->
							</div>
							<?php } ?>
						</div>	

					</div>
					<!--div class="col-md-4">
						<div class="featured-box featured-box-secondary sidebar">
							<div class="box-content">
							<form method="post" action="" name="place_order" id="place_order">
								<?php $i = 1; ?>
								<?php foreach ($this->cart->contents() as $items): ?>
									<div>
										
											<input type="hidden" name="product-id" id="product-id" value="<?php echo $items['id']; ?>">
											<input type="hidden" name="product-name" id="product-name" value="<?php echo $items['name']; ?>">
											<input type="hidden" name="amount" id="amount" value="<?php echo $items['price']; ?>">
											<input type="hidden" name="total" id="total" value="<?php echo $this->cart->format_number($this->cart->total()); ?>">
										
									</div>
								<?php $i++; ?>
								<?php endforeach; ?>
							</form>
							</div>
						</div>
					</div-->
				</div>
				</div>
		</div>
		<!-- End Main -->
<?php include('footer.php');?>