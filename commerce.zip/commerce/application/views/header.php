<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="robots" content="all,follow">
    <meta name="googlebot" content="index,follow,snippet,archive">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>E-commerce</title>
    <meta name="keywords" content="">
    <link href="<?php echo base_url(); ?>assets/css/font-awesome.css" rel="stylesheet">
    <link href="<?php echo base_url(); ?>assets/css/bootstrap.min.css" rel="stylesheet">
    <link href="<?php echo base_url(); ?>assets/css/style.default.css" rel="stylesheet" id="theme-stylesheet">
    <link href="<?php echo base_url(); ?>assets/css/owl.carousel.css" rel="stylesheet">
    <link href="<?php echo base_url(); ?>assets/css/owl.theme.css" rel="stylesheet">
    <link href="<?php echo base_url(); ?>assets/css/style.css" rel="stylesheet">
</head>
<body class="no-padding">
	<header>
	<?php 	$userid = $this->session->userdata('user');
			$getUserById = $this->product_model->getUserById($userid['user_id']);
	?>
		<div class="navbar navbar-default navbar-fixed-top yamm" role="navigation" id="navbar">
			<div class="container">
				<a class="navbar-brand home" href="<?php echo base_url();?>">
					<img class="img-responsive" src="<?php echo base_url(); ?>assets/images/logo.png" alt="Minimal logo" class="">
				</a>
				<div class="navbar-header pull-right">
					<div class="navbar-buttons">
						<button type="button" class="navbar-toggle btn-primary" data-toggle="collapse" data-target="#navigation">
							<span class="sr-only">Toggle navigation</span>
							<i class="fa fa-align-justify"></i>
						</button>
					</div>
					
					<div class="pull-right">
						<div class="">
						<div class="nav_icons right">
							<a type="button" class="" data-toggle="collapse" data-target="#search">
								<span class="sr-only">Toggle search</span>
								<i class="fa fa-search"></i>
							</a>
						</div>
						<?php if($getUserById){ ?>
						<div class="nav_icons right">
							<i class="fa fa-heart-o"></i>
							<span>3</span>
						</div>
						<?php } ?> 
						<div class="nav_icons right">
							<a href="<?php echo base_url();?>cart">
								<i class="fa fa-shopping-bag"></i>
							</a>
							<span><?php echo $rows = count($this->cart->contents());?></span>
						</div>
						
						<?php if($getUserById){ ?>
						<div style="float: right; margin: 10px 0 0 10px;">
							<div class="user_sec">
								<div class="dropdown user_detail">
									<span class="dropdown-toggle" type="button" data-toggle="dropdown">
										<?php 	if(!empty($getUserById->F_name)){
													echo $getUserById->F_name;
												}else{
													echo $getUserById->E_mail;
												}
										?>
										<i class="fa fa-caret-down"></i>
									</span>
									<ul class="dropdown-menu">
										<li><a href="<?php echo base_url();?>logout">Logout</a></li>
										<!--li><a href="#">CSS</a></li>
										<li><a href="#">JavaScript</a></li-->
									</ul>
								</div>
								<?php /*if(!empty($getUserById->F_name)){ ?>
								<?php }*/ ?>
								<div class="image-design">
									<img  src="<?php echo base_url(); ?>assets/images/<?php echo $getUserById->P_image;?>">
								</div>
							</div>
						</div>
						<?php } else { ?>
							<div class="nav_icons right">
								<a class="user_sec" href="<?php echo base_url(); ?>login">Login</a>
								<a class="user_sec" href="<?php echo base_url(); ?>signUp">Signup</a>
							</div>
						<?php } ?>
			
						<div class="cust_align collapse clearfix" id="search">
							<form method="post" class="navbar-form" role="search" action="<?php echo base_url();?>shoppingcart/search_ByName">
								<div class="input-group">
									<input type="text" class="form-control" placeholder="Search" name="search">
									<span class="input-group-btn">
										<button type="submit" class="btn btn-primary"><i class="fa fa-search"></i></button>
									</span>
								</div>
							</form>
						</div>
						</div>
						<!--/.nav-collapse -->
					</div>
					
				</div>
				<!--/.navbar-header -->

				<div class="navbar-collapse collapse" id="navigation">

					<ul class="nav navbar-nav navbar-left">
						<!--li class="active dropdown normal-dropdown"><a href="index-2.html" class="dropdown-toggle" data-toggle="dropdown">Collection <b class="fa fa-chevron-down"></b></a>
							<ul class="dropdown-menu">
								<li><a href="#">Home - default</a>
								</li>
								<li><a href="#">Home - intro image</a>
								</li>
							</ul>
						</li-->
						<li class="dropdown yamm-fw">
							<a href="#" class="dropdown-toggle" data-toggle="dropdown">Men <b class="fa fa-chevron-down"></b></a>
							<ul class="dropdown-menu">
								<li>
									<div class="yamm-content">
										<div class="row">
											
											<div class="col-sm-3">
												<h3>Clothing</h3>
												<ul>
													<?php $mens_clothings = $this->categories_model->mens_clothing(); ?>
													<?php foreach($mens_clothings as $mens_categorie){ ?>
														<li><a href="<?php echo base_url();?>searchProduct?id=<?php echo $mens_categorie->id; ?>"><?php echo $mens_categorie->cat_name; ?></a></li>
													<?php } ?>
												</ul>
											</div>
											
											<div class="col-sm-3">
												<h3>footwear</h3>
												<ul>
													<?php $mens_footwears = $this->categories_model->mens_footwear(); ?>
													<?php foreach($mens_footwears as $mens_footwear){ ?>
														<li><a href="<?php echo base_url();?>searchProduct?id=<?php echo $mens_footwear->id; ?>"><?php echo $mens_footwear->cat_name; ?></a></li>
													<?php } ?>
												</ul>
											</div>
											
											<div class="col-sm-3">
												<h3>Watches</h3>
												<ul>
													<?php $mens_watches = $this->categories_model->mens_watches(); ?>
													<?php foreach($mens_watches as $mens_watche){ ?>
													<li><a href="<?php echo base_url();?>searchProduct?id=<?php echo $mens_watche->id; ?>"><?php echo $mens_watche->cat_name; ?></a></li>
													<?php } ?>
												</ul>
												<h3>Accessories</h3>
												<ul>
													<?php $mens_accessories = $this->categories_model->mens_accessories(); ?>
													<?php foreach($mens_accessories as $mens_accessorie){ ?>
													<li><a href="<?php echo base_url();?>searchProduct?id=<?php echo $mens_accessorie->id; ?>"><?php echo $mens_accessorie->cat_name; ?></a></li>
													<?php } ?>
												</ul>
											</div>
											<div class="col-sm-3">
												<h3>Personal Care</h3>
												<ul>
													<?php $mens_personalcares = $this->categories_model->mens_personalcare(); ?>
													<?php foreach($mens_personalcares as $mens_personalcare){ ?>
														<li><a href="<?php echo base_url();?>searchProduct?id=<?php echo $mens_personalcare->id; ?>"><?php echo $mens_personalcare->cat_name; ?></a></li>
													<?php } ?>
												</ul>
												<h3>Mens Grooming</h3>
												<ul>
													<?php $mens_groomings = $this->categories_model->mens_grooming(); ?>
													<?php foreach($mens_groomings as $mens_grooming){ ?>
														<li><a href="<?php echo base_url();?>searchProduct?id=<?php echo $mens_grooming->id; ?>"><?php echo $mens_grooming->cat_name; ?></a></li>
													<?php } ?>
												</ul>
											</div>
											
										</div>
									</div>
									<!--div class="footer clearfix hidden-xs">
										<h4 class="pull-right">Men</h4>
										<div class="buttons pull-left">
											<a href="#" class="btn btn-default"><i class="fa fa-tags"></i> Sales</a>
											<a href="#" class="btn btn-default"><i class="fa fa-star-o"></i> Favourites</a>
											<a href="#" class="btn btn-default"><i class="fa fa-globe"></i> Brands</a>
										</div>
									</div-->

								</li>
							</ul>
						</li>
						<li class="dropdown yamm-fw">
							<a href="#" class="dropdown-toggle" data-toggle="dropdown">Women <b class="fa fa-chevron-down"></b></a>
							<ul class="dropdown-menu">
								<li>
									<div class="yamm-content">
										<div class="row">
											<!--div class="col-sm-3">
											<img src="<?php echo base_url(); ?>assets/images/women.jpg" class="img-responsive hidden-xs" alt="">
											</div-->
											<div class="col-sm-3">
												<h3>Clothing</h3>
												<h5>Western Wear</h5>
													<ul>
														<?php $womens_westens = $this->categories_model->womens_westenwear(); ?>
														<?php foreach($womens_westens as $womens_westen){ ?>
															<li><a href="<?php echo base_url();?>searchProduct?id=<?php echo $womens_westen->id; ?>"><?php echo $womens_westen->cat_name; ?></a></li>
														<?php } ?>
													</ul>
												<h5>Winter Wear</h5>
													<ul>	
														<?php $womens_winterwears = $this->categories_model->womens_winterwear(); ?>
														<?php foreach($womens_winterwears as $womens_winterwear){ ?>	
															<li><a href="<?php echo base_url();?>searchProduct?id=<?php echo $womens_winterwear->id; ?>"><?php echo $womens_winterwear->cat_name; ?></a></li>
														<?php } ?>	
													</ul>
											</div>	
											<div class="col-sm-3">
												<h5>Ethnic Wear</h5>
													<ul>
														<?php $womens_ethnicwears = $this->categories_model->womens_ethnicwear(); ?>
														<?php foreach($womens_ethnicwears as $womens_ethnicwear){ ?>
															<li><a href="<?php echo base_url();?>searchProduct?id=<?php echo $womens_ethnicwear->id; ?>"><?php echo $womens_ethnicwear->cat_name; ?></a></li>
														<?php } ?>
													</ul>
												<h5>Lingerie & Sleepwear</h5>
													<ul>
														<?php $womens_sleepwears = $this->categories_model->womens_sleepwear(); ?>
														<?php foreach($womens_sleepwears as $womens_sleepwear){ ?>
															<li><a href="<?php echo base_url();?>searchProduct?id=<?php echo $womens_sleepwear->id; ?>"><?php echo $womens_sleepwear->cat_name; ?></a></li>	
														<?php } ?>
													</ul>
											</div>	
											<div class="col-sm-3">	
												<h5>Footwear</h5>
													<ul>	
														<?php $womens_footwears = $this->categories_model->womens_footwear(); ?>	
														<?php foreach($womens_footwears as $womens_footwear){ ?>		
															<li><a href="<?php echo base_url();?>searchProduct?id=<?php echo $womens_footwear->id; ?>"><?php echo $womens_footwear->cat_name; ?></a></li>
														<?php } ?>
													</ul>
												<h5></h5>
													<ul>
														<?php $womens_watches = $this->categories_model->womens_watches(); ?>
														<?php foreach($womens_watches as $womens_watche){ ?>
															<li><a href="<?php echo base_url();?>searchProduct?id=<?php echo $womens_watche->id; ?>"><?php echo $womens_watche->cat_name; ?></a></li>
														<?php } ?>
													</ul>
												<h3>Personal Care Appliances</h3>
													<ul>
														<?php $womens_personalcares = $this->categories_model->womens_personalcare(); ?>
														<?php foreach($womens_personalcares as $womens_personalcare){ ?>
															<li><a href="<?php echo base_url();?>searchProduct?id=<?php echo $womens_personalcare->id; ?>"><?php echo $womens_personalcare->cat_name; ?></a></li>
														<?php } ?>
													</ul>
											</div>
											<div class="col-sm-3">
												<h3>Beauty & Grooming</h3>
													<ul>	
														<?php $womens_beautys = $this->categories_model->womens_beauty(); ?>
														<?php foreach($womens_beautys as $womens_beauty){ ?>
															<li><a href="<?php echo base_url();?>searchProduct?id=<?php echo $womens_beauty->id; ?>"><?php echo $womens_beauty->cat_name; ?></a></li>
														<?php } ?>
													</ul>
												<h3>Accessories</h3>
													<ul>	
														<?php $womens_accessorie = $this->categories_model->womens_accessories(); ?>
														<?php foreach($womens_accessorie as $womens_accessories){ ?>
															<li><a href="<?php echo base_url();?>searchProduct?id=<?php echo $womens_accessories->id; ?>"><?php echo $womens_accessories->cat_name; ?></a></li>
														<?php } ?>
													</ul>
												<h3>Jewellery</h3>
													<ul>
														<?php $womens_jewellerys = $this->categories_model->womens_jewellery(); ?>
														<?php foreach($womens_jewellerys as $womens_jewellery){ ?>
															<li><a href="<?php echo base_url();?>searchProduct?id=<?php echo $womens_jewellery->id; ?>"><?php echo $womens_jewellery->cat_name; ?></a></li>	
														<?php } ?>	
													</ul>	
											</div>
										</div>	
									</div>
								</li>
							</ul>
						</li>
						
						<li class="dropdown yamm-fw">
							<a href="#" class="dropdown-toggle" data-toggle="dropdown" data-hover="dropdown" data-delay="200">Blog</a>
						</li>
						<li>
							<a href="#">Faq</a>
						</li>
					</ul>
				</div>
				<!--/.nav-collapse -->
			</div>
		</div>
		<!-- /#navbar -->
	</header>