<footer>
		<div id="copyright">
            <div class="container">
                <div class="footer_txt col-md-12">
					<ul>
						<li><a href="#">YOUR ACCOUNT</a></li>
						<li><a href="#">CONTACT US</a></li>
						<li><a href="#">TERMS OF SERVICE</a></li>
					</ul>
					<ul>
						<li><a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
						<li><a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
						<li><a href="#"><i class="fa fa-instagram" aria-hidden="true"></i></a></li>
						<li><a href="#"><i class="fa fa-pinterest-p" aria-hidden="true"></i></a></li>
					</ul>
                    <p>Copyright © 2017 <a href="http://i-tuffgeekers.com/" target="_blank">i-Tuffgeekers.com</a></p>
                </div>
            </div>
        </div>
	</footer>
	
    <!-- #### JAVASCRIPT FILES ### -->
    <script src="<?php echo base_url(); ?>assets/js/jquery-1.11.0.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/bootstrap.min.js"></script> 
	<script src="<?php echo base_url(); ?>assets/js/jquery.cookie.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/front.js"></script> 
	<script src="<?php echo base_url(); ?>assets/js/owl.carousel.min.js"></script>
	<script src="<?php echo base_url(); ?>assets/js/jquery-1.7.1.min.js"></script>
	<script src="<?php echo base_url(); ?>assets/js/prefixfree.js"></script> 
	<script src="<?php echo base_url(); ?>assets/js/min.js"></script> 
	<script src="<?php echo base_url(); ?>assets/js/checkout.js"></script>
	<script src="<?php echo base_url(); ?>assets/js/custom.js"></script>
	<script src="//code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
</body>
</html>