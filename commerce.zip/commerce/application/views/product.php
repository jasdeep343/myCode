<?php include('header.php'); ?>
	<section>
		<div class="container">
			<div class="row">
				<div class="col-sm-3">
					<div class="left-sidebar">
						<div class="discount-range"><!--brands_products-->
							<h4>Discount</h4>
							<div class="discount-price">
								<form action="">
									<input type="checkbox" name="vehicle" class="check-range" value="Bike"> <span>50% to 70%</span><br><br>
									<input type="checkbox" name="vehicle" class="check-range" value="Car"> <span>70% to 80%</span> 
								</form>
							</div>
						</div><!--/brands_products-->
					    
						<div class="price-range"><!--price-range-->
							<h4>Price Range</h4>
							<div class="discount-price">
								<form action="">
									<input type="checkbox" name="vehicle" class="check-range" value="Bike"> <span> 100 to 499</span><br><br>
									<input type="checkbox" name="vehicle" class="check-range" value="Car"> <span> 500 to 999</span><br><br>
									<input type="checkbox" name="vehicle" class="check-range" value="Bike"> <span> 1000 to 1499</span><br><br>
									<input type="checkbox" name="vehicle" class="check-range" value="Car"> <span> 1500 to 2000</span>									
								</form>
							</div>
						</div><!--/price-range-->
					
					    <div class="category-section">
						<h4>Category</h4>
						<div class="panel-group category-products" id="accordian"><!--category-productsr-->
							<div class="panel panel-default">
								<div class="panel-heading">
									<h4 class="panel-title">
										<a data-toggle="collapse" data-parent="#accordian" href="#sportswear">
											<span class="badge pull-right"><i class="fa fa-plus"></i></span>
											Sportswear
										</a>
									</h4>
								</div>
								<div id="sportswear" class="panel-collapse collapse">
									<div class="panel-body">
										<ul>
											<li><a href="#">Nike </a></li>
											<li><a href="#">Under Armour </a></li>
											<li><a href="#">Adidas </a></li>
											<li><a href="#">Puma</a></li>
											<li><a href="#">ASICS </a></li>
										</ul>
									</div>
								</div>
							</div>
							<div class="panel panel-default">
								<div class="panel-heading">
									<h4 class="panel-title">
										<a data-toggle="collapse" data-parent="#accordian" href="#mens">
											<span class="badge pull-right"><i class="fa fa-plus"></i></span>
											Mens
										</a>
									</h4>
								</div>
								<div id="mens" class="panel-collapse collapse">
									<div class="panel-body">
										<ul>
											<li><a href="#">Fendi</a></li>
											<li><a href="#">Guess</a></li>
											<li><a href="#">Valentino</a></li>
											<li><a href="#">Dior</a></li>
											<li><a href="#">Versace</a></li>
											<li><a href="#">Armani</a></li>
											<li><a href="#">Prada</a></li>
											<li><a href="#">Dolce and Gabbana</a></li>
											<li><a href="#">Chanel</a></li>
											<li><a href="#">Gucci</a></li>
										</ul>
									</div>
								</div>
							</div>
							
							<div class="panel panel-default">
								<div class="panel-heading">
									<h4 class="panel-title">
										<a data-toggle="collapse" data-parent="#accordian" href="#womens">
											<span class="badge pull-right"><i class="fa fa-plus"></i></span>
											Womens
										</a>
									</h4>
								</div>
								<div id="womens" class="panel-collapse collapse">
									<div class="panel-body">
										<ul>
											<li><a href="#">Fendi</a></li>
											<li><a href="#">Guess</a></li>
											<li><a href="#">Valentino</a></li>
											<li><a href="#">Dior</a></li>
											<li><a href="#">Versace</a></li>
										</ul>
									</div>
								</div>
							</div>
							<div class="panel panel-default">
								<div class="panel-heading">
									<h4 class="panel-title"><a href="#">Kids</a></h4>
								</div>
							</div>
							<div class="panel panel-default">
								<div class="panel-heading">
									<h4 class="panel-title"><a href="#">Fashion</a></h4>
								</div>
							</div>
							<div class="panel panel-default">
								<div class="panel-heading">
									<h4 class="panel-title"><a href="#">Households</a></h4>
								</div>
							</div>
							<div class="panel panel-default">
								<div class="panel-heading">
									<h4 class="panel-title"><a href="#">Interiors</a></h4>
								</div>
							</div>
							<div class="panel panel-default">
								<div class="panel-heading">
									<h4 class="panel-title"><a href="#">Clothing</a></h4>
								</div>
							</div>
							<div class="panel panel-default">
								<div class="panel-heading">
									<h4 class="panel-title"><a href="#">Bags</a></h4>
								</div>
							</div>
							<div class="panel panel-default">
								<div class="panel-heading">
									<h4 class="panel-title"><a href="#">Shoes</a></h4>
								</div>
							</div>
						</div>
						</div><!--/category-products-->
					
						<div class="brands_products"><!--brands_products-->
							<h4>Brands</h4>
							<div class="brands-name">
								<ul class="nav nav-pills nav-stacked">
									<li><a href="#"> <span class="pull-right">(50)</span>Acne</a></li>
									<li><a href="#"> <span class="pull-right">(56)</span>Grüne Erde</a></li>
									<li><a href="#"> <span class="pull-right">(27)</span>Albiro</a></li>
									<li><a href="#"> <span class="pull-right">(32)</span>Ronhill</a></li>
									<li><a href="#"> <span class="pull-right">(5)</span>Oddmolly</a></li>
									<li><a href="#"> <span class="pull-right">(9)</span>Boudestijn</a></li>
									<li><a href="#"> <span class="pull-right">(4)</span>Rösch creative culture</a></li>
								</ul>
							</div>
						</div><!--/brands_products-->
					</div>
				</div>
				
				<div id="content" class="col-sm-9 new_products">
					<div class="row products">
						<?php foreach($products as $product) {	?>						<?php $categories_model =  $this->categories_model->productDetails($product->id);?>
						<div class="col-md-4 col-sm-4 cust_col">
							<div class="product">
								<div class="image" style="height: 255px;">									<a href="#">										<img src="<?php echo base_url(); ?>assets/images/<?php echo $categories_model->image;?>" alt="" class="img-responsive image1">									</a>									<div class="quick-view-button">										<a href="<?php echo base_url();?>product_page?id=<?php echo $product->id; ?>" data-target="#" class="btn btn-default btn-sm">Quick view</a>									</div>								</div>
							</div>
							<div class="product_txt text-center">
								<h4><a class="product_name font_new" href="#"><?php echo $product->description;?></a></h4>
								<p class="price"><!--del>$280</del--><a href="#"> $<?php echo $categories_model->price;?></a></p>
							</div>
						</div>
						<?php } ?>
						
					</div>
					<!--div class="all_product">
						<a href="#" class="text_border font_new">BROWS ALL ITEMS</a>
					</div-->
				</div>
			</div>
		</div>
	</section>
<?php include('footer.php');?>