<?php
class product_model extends CI_Model{
	
	public function __construct() {
		parent::__construct();
	}
	
	function find_all(){
		return $this->db->get('products')->result();
	}
	
	function find($id){
		$this->db->where('id',$id);
		return $this->db->get('products')->row();
	}
	
	function product_byid($id){
		$this->db->where('category_id',$id);
		return $this->db->get('products')->result();
	}

}
?>
