<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class index extends CI_Controller {

	public function __construct(){
		parent::__construct();
		$this->load->model("product_model");
		$this->load->model("categories_model");
		$this->load->library('cart');
	}
	
	public function index($index = 0){
		//$this->cart();
		$data['products'] = $this->product_model->find_all();
		$this->load->view("index",$data);
	}
	
	
}
  
