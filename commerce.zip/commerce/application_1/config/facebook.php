<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

$config['appID']	= '690448191085473';


$config['appSecret']	= '4d8b8d6c4aeb0b2ac6632934365c4025';


/* End of file facebook.php */
/* Location: ./application/config/facebook.php */