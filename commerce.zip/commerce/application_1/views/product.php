<?php include('header.php'); ?>
	<section>
		<div class="container">
			<div class="row">
				<div id="content" class="col-xs-12 new_products">
					<div class="row products">
						<?php foreach($products as $product) {	?>
						<div class="col-md-3 col-sm-4 cust_col">
							<div class="product">
								<div class="image" style="height: 255px;">
									<a href="#">
										<!--img src="<?php echo base_url(); ?>assets/images/product6.png" alt="" class="img-responsive image1"-->
										<img src="<?php echo base_url(); ?>assets/images/<?php echo $product->image_name;?>" alt="" class="img-responsive image1">
									</a>
									<div class="quick-view-button">
										<a href="<?php echo base_url();?>shoppingcart/buy/<?php echo $product->id; ?>" data-target="#" class="btn btn-default btn-sm">Add To Cart</a>
										<a href="#" data-target="#" class="btn btn-default btn-sm">Quick view</a>
									</div>
								</div>
							</div>
							<div class="product_txt text-center">
								<h4><a class="product_name font_new" href="#"><?php echo $product->description;?></a></h4>
								<p class="price"><del>$280</del><a href="#"> $<?php echo $product->price;?></a></p>
							</div>
						</div>
						<?php } ?>
						
					</div>
					<!--div class="all_product">
						<a href="#" class="text_border font_new">BROWS ALL ITEMS</a>
					</div-->
				</div>
			</div>
		</div>
	</section>
<?php include('footer.php');?>