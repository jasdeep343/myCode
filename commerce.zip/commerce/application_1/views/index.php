<?php include('header.php'); ?>
	<section>
		<div id="intro">
			<div class="item">
				<div class="container">
					<div class="">
						<div class="carousel_caption">
							<h1 class="font_new">Kenakata Summer<br>Collection</h1>
							<h3>Excepteur sint occaecat cupidatat non proident, sunt in culpa qui deserunt mollit anim id est laborum.</h3>
							<p><a class="btn btn-lg btn-default font_new" href="#" role="button">Shop Now</a>
							</p>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	<section>
		<div class="container">
			<div class="row">
				<div id="content" class="col-xs-12 new_products">
					<div class="box text-center">
						<h3 class="text-muted text_border font_new">New Products</h3>
						<p class="text-muted text-uppercase">dolor sit amet</p>
					</div>
					<div class="row products">
						<?php foreach($products as $product) {		?>
						<div class="col-md-3 col-sm-4 cust_col">
							<div class="product">
								<div class="image" style="height: 255px;">
									<a href="#">
										<!--img src="<?php echo base_url(); ?>assets/images/product6.png" alt="" class="img-responsive image1"-->
										<img src="<?php echo base_url(); ?>assets/images/<?php echo $product->image_name;?>" alt="" class="img-responsive image1">
									</a>
									<div class="quick-view-button">
										<a href="<?php echo base_url();?>shoppingcart/buy/<?php echo $product->id; ?>" data-target="#" class="btn btn-default btn-sm">Add To Cart</a>
										<a href="#" data-target="#" class="btn btn-default btn-sm">Quick view</a>
									</div>
								</div>
							</div>
							<div class="product_txt text-center">
								<h4><a class="product_name font_new" href="#"><?php echo $product->description;?></a></h4>
								<p class="price"><del>$280</del><a href="#"> $<?php echo $product->price;?></a></p>
							</div>
						</div>
						<?php } ?>
						
					</div>
					<!--div class="all_product">
						<a href="#" class="text_border font_new">BROWS ALL ITEMS</a>
					</div-->
				</div>
			</div>
		</div>
	</section>
	<section>
		<div class="bar background-image-fixed-2 no-mb color-white text-center">
			<div class="dark-mask"></div>
			<div class="container">
				<div class="row">
					<div class="col-md-12 shopnow_sec">
						<h1 class="pull-left">Get something you love</h1>
						<p class="pull-right">
							<a href="#" class="btn btn-default btn-sm font_new">Shop Now</a>
						</p>
					</div>
				</div>
			</div>
		</div>
	</section>
	<section>
		<!-- *** SLIDER *** -->
		<div class="container">
			<div id="content" class="col-xs-12 new_products">
				<div class="box text-center">
					<h3 class="text-muted text_border font_new">Fetured Products</h3>
					<p class="text-muted text-uppercase">EDITORS� PICKS</p>
				</div>
				<div class="row products">
					<div id="slider" class="owl-carousel owl-theme">
						<div class="item">
							<div class="">
								<div class="product">
									<div class="image" style="height: 255px;">
										<span>
											<img src="<?php echo base_url(); ?>assets/images/product8.png" alt="" class="img-responsive image1">
										</span>
										<div class="quick-view-button">
											<a href="#" data-target="#" class="btn btn-default btn-sm">Add to csrt</a>
											<a href="#" data-target="#" class="btn btn-default btn-sm">Quick view</a>
										</div>
									</div>
								</div>
								<div class="product_txt text-center">
									<h4><a class="product_name font_new" href="#">Cotton Polo Shirt</a></h4>
									<p class="price"><a href="#"> $143.00</a></p>
								</div>
							</div>
						</div>
						<div class="item">
							<div class="">
								<div class="product">
									<div class="image" style="height: 255px;">
										<span>
											<img src="<?php echo base_url(); ?>assets/images/product9.png" alt="" class="img-responsive image1">
										</span>
										<div class="quick-view-button">
											<a href="#" data-target="#" class="btn btn-default btn-sm">Add to csrt</a>
											<a href="#" data-target="#" class="btn btn-default btn-sm">Quick view</a>
										</div>
									</div>
								</div>
								<div class="product_txt text-center">
									<h4><a class="product_name font_new" href="#">Cotton Polo Shirt</a></h4>
									<p class="price"><a href="#"> $143.00</a></p>
								</div>
							</div>
						</div>
						<div class="item">
							<div class="">
								<div class="product">
									<div class="image" style="height: 255px;">
										<span>
											<img src="<?php echo base_url(); ?>assets/images/product10.png" alt="" class="img-responsive image1">
										</span>
										<div class="quick-view-button">
											<a href="#" data-target="#" class="btn btn-default btn-sm">Add to csrt</a>
											<a href="#" data-target="#" class="btn btn-default btn-sm">Quick view</a>
										</div>
									</div>
								</div>
								<div class="product_txt text-center">
									<h4><a class="product_name font_new" href="#">Cotton Polo Shirt</a></h4>
									<p class="price"><a href="#"> $143.00</a></p>
								</div>
							</div>
						</div>
						<div class="item">
							<div class="">
								<div class="product">
									<div class="image" style="height: 255px;">
										<span>
											<img src="<?php echo base_url(); ?>assets/images/product9.png" alt="" class="img-responsive image1">
										</span>
										<div class="quick-view-button">
											<a href="#" data-target="#" class="btn btn-default btn-sm">Add to csrt</a>
											<a href="#" data-target="#" class="btn btn-default btn-sm">Quick view</a>
										</div>
									</div>
								</div>
								<div class="product_txt text-center">
									<h4><a class="product_name font_new" href="#">Cotton Polo Shirt</a></h4>
									<p class="price"><a href="#"> $143.00</a></p>
								</div>
							</div>
						</div>
						<div class="item">
							<div class="">
								<div class="product">
									<div class="image" style="height: 255px;">
										<span>
											<img src="<?php echo base_url(); ?>assets/images/product8.png" alt="" class="img-responsive image1">
										</span>
										<div class="quick-view-button">
											<a href="#" data-target="#" class="btn btn-default btn-sm">Add to csrt</a>
											<a href="#" data-target="#" class="btn btn-default btn-sm">Quick view</a>
										</div>
									</div>
								</div>
								<div class="product_txt text-center">
									<h4><a class="product_name font_new" href="#">Cotton Polo Shirt</a></h4>
									<p class="price"><a href="#"> $143.00</a></p>
								</div>
							</div>
						</div>
						<div class="item">
							<div class="">
								<div class="product">
									<div class="image" style="height: 255px;">
										<span>
											<img src="<?php echo base_url(); ?>assets/images/product9.png" alt="" class="img-responsive image1">
										</span>
										<div class="quick-view-button">
											<a href="#" data-target="#" class="btn btn-default btn-sm">Add to csrt</a>
											<a href="#" data-target="#" class="btn btn-default btn-sm">Quick view</a>
										</div>
									</div>
								</div>
								<div class="product_txt text-center">
									<h4><a class="product_name font_new" href="#">Cotton Polo Shirt</a></h4>
									<p class="price"><a href="#"> $143.00</a></p>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<!-- #slider -->
	</section>
	<section>
		<div class="dark-bg-mask">
			<div class="container">
				<div class="bar background-image-fixed-1 no-mb color-white text-center">
					<div class="row">
						<div class="col-md-12 logos_sec">
							<img src="<?php echo base_url(); ?>assets/images/brand-1.png">
							<img src="<?php echo base_url(); ?>assets/images/brand-2.png">
							<img src="<?php echo base_url(); ?>assets/images/brand-3.png">
							<img src="<?php echo base_url(); ?>assets/images/brand-4.png">
							<img src="<?php echo base_url(); ?>assets/images/brand-5.png">
							<img src="<?php echo base_url(); ?>assets/images/brand-6.png">
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	<section>
		<div class="container">
			<div class="row">
				<div class="custom_well text-center">
					<h2 class="font_new">Join 100,000 members already collaborating </h2>
					<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation</p>
					<form action="" method="post">
						<div class="input-prepend">
							<input type="text" id="" name="" placeholder="Your email address">
							<input type="submit" value="Subscribe" class="btn btn-large" />
						</div>
				  </form>
				</div>    
			</div>
		</div>
	</section>
<?php include('footer.php');?>