<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?php echo  ucfirst($master_title); ?></title>
<?php include("head.php"); ?>                     		
</head>
<body>
 <?php include("header.php"); ?> 
 <section>
 <div class="first_section">
 <div class="row_slider_img">
    <div id="myCarousel" class="carousel slide" data-ride="carousel">
        <!-- Carousel indicators -->
        <ol class="carousel-indicators">
            <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
            <li data-target="#myCarousel" data-slide-to="1"></li>
            <li data-target="#myCarousel" data-slide-to="2"></li>
        </ol>   
        <!-- Wrapper for carousel items
        <div class="carousel-inner">
            <div class="item active">
                <img class="img-responsive" src="<?php echo base_url(); ?>assets/images/sec-bg.png" />
            </div>
            <div class="item">
                <img class="img-responsive" src="<?php echo base_url(); ?>assets/images/jobs-banner.jpg" />
            </div>
            <div class="item">
                <img class="img-responsive" src="<?php echo base_url(); ?>assets/images/Layer-8.png" />
            </div>
        </div>
		 Wrapper for carousel items -->
		 
		<div class="carousel-inner">
            <div class="slide_a item active">
                <div class="publisher-banner">
					<h1>Get Started Immediately</h1>
					<div class="clearfix"></div>
					<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s.</p>
					<a href="sign-up">Signup Here</a> &nbsp; &nbsp; <a href="#">Learn More</a>
				</div>
            </div>
            <div class="slide_b item">
                <div class="publisher-banner">
					<h1>Get Started Immediately</h1>
					<div class="clearfix"></div>
					<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s.</p>
					<a href="sign-up">Signup Here</a> &nbsp; &nbsp; <a href="#">Learn More</a>
				</div>
            </div>
            <div class="slide_c item">
                <div class="publisher-banner">
					<h1>Get Started Immediately</h1>
					<div class="clearfix"></div>
					<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s.</p>
					<a href="sign-up">Signup Here</a> &nbsp; &nbsp; <a href="#">Learn More</a>
				</div>
            </div>
        </div>
		
        <!-- Carousel controls -->
		<div class="carousel_control_icons">
			<a class="carousel-control left" href="#myCarousel" data-slide="prev">
				<span class="glyphicon glyphicon-chevron-left"></span>
			</a>
			<a class="carousel-control right" href="#myCarousel" data-slide="next">
				<span class="glyphicon glyphicon-chevron-right"></span>
			</a>
		</div>
    </div>
</div>

<div class="col-md-12 col-sm-12 col-xs-12 socialsite_row socialsite_row_bg">
    <div class="container">
	     <div class="row_sub_heading text-center">
				<h3>What We Do</h3>
		</div>
        <div class="col-sm-6">
            <div class="services_new_sec">
                <h4><i class="fa fa-download" aria-hidden="true"></i> Engage Your Fans</h4>
                <p>Engage Your Fans Our machine learning algorithms analyze your audience and recommend relevant 
                content for you to create and share on your social media page.</p>
            </div>
        </div>
        <div class="col-sm-6">
            <div class="services_new_sec">
                <h4><i class="fa fa-paper-plane" aria-hidden="true"></i> Maximize Your Revenue</h4>
                <p>Hosting and monetizing content using MyLikes is simpler and more effective than on other 
                systems. By targeting the right social content ads to your audience we maximize your revenue.</p>
            </div>
        </div>
        <div class="col-sm-6">
            <div class="services_new_sec">
                <h4><i class="fa fa-lightbulb-o" aria-hidden="true"></i> Get Started Immediately</h4>
                <p>Creating your own unique social website is extremely simple. You can customize your content 
                and layout to your social media presence in a few minutes.</p>
            </div>
        </div>
		<div class="col-sm-6">
			<div class="services_new_sec">
                <h4><i class="fa fa-dot-circle-o" aria-hidden="true"></i>Highly Targeted</h4>
                <p>We use artificial intelligence to learn the type of audience that engages most with your 
                    campaigns and drive relevant traffic in minutes</p>
            </div>
        </div>
    </div>
</div>


<div class="col-md-12 col-sm-12 col-xs-12 socialsite_row popular_post">
    <div class="">
		<div class="col-md-12 row_sub_heading text-center slider_bg">
			<h3>Most Popular Posts</h3>
		</div>
		<div class="col-md-12 slider_bg">
		<ul class="bxslider">
            <?php
if(!empty($PopularPosts)){
foreach($PopularPosts as $key1=>$val1){
	$GetPostdatas = $this->post_model->GetPostdata($val1['postid']);
 	 ?>
            
			<li>
			<div class="">
				<div class="">
					<div class="well">
					  <div class="media">
						<a class="pull-left" href="<?php echo $GetPostdatas['slug_title'];?>" target="_blank">
							<img class="media-object" src="./assets/images/place.png">
						</a>
						<div class="media-body">
						  <h3 class="media-heading"><a href="<?php echo $GetPostdatas['slug_title'];?>" target="_blank"> <p><?php   echo substr($GetPostdatas['title'], 0,20);?>.</p></a></h3>
						 <p><?php   echo substr($GetPostdatas['description'], 0,15);?>.</p>
						  <ul class="list-inline list-unstyled blog-comment-style">
 							<li class="blog_social_icon">
							  <span><i class="fa fa-facebook"></i><span>15</span></span>|
							  <span><i class="fa fa-twitter"></i><span>10</span></span>|
 							</li>
						  </ul>
					   </div>
					</div>
				  </div>
				</div>
			</div>
			</li>
 <?php } }else{?>
 		<div style=" font-size: 20px; text-align: center;">No result Found</div>
 <?php } ?>
 		</ul>
		</div>
    </div>
</div>
   <div class="col-md-12 col-sm-12 col-xs-12 socialsite_row socialsite_row_bg">
    <div class="container">
		<div class="col-md-12 row_sub_heading text-center">
			<h3>All the latest stories</h3>
		</div>
		<div class="col-md-9">
        <?php
if(!empty($ShowAllPosts)){
foreach($ShowAllPosts as $key=>$val){ ?>

			<div class="">
				<div class="">
					<div class="well">
					  <div class="media">
						<a class="pull-left" href="<?php echo $val['slug_title'];?>" target="_blank">
							<img class="media-object" src="<?php echo $this->config->item('admin_url'); ?>/upload/<?php echo $val['image'];?>">
						</a>
						<div class="media-body">
						  <h3 class="media-heading"><a href="<?php echo $val['slug_title'];?>" target="_blank"><?php echo ucfirst($val['title']);?> </a></h3>
						  <p><?php   echo substr($val['description'], 0,50);?>.</p>
						  <ul class="list-inline list-unstyled blog-comment-style">
 							
 							<li class="blog_social_icon">
							  <span><i class="fa fa-facebook"></i><span>15</span></span>|
							  <span><i class="fa fa-twitter"></i><span>10</span></span>|
 							</li>
						  </ul>
					   </div>
					</div>
				  </div>
				</div>
			</div>
 <?php } }else{?>
 		<div style=" font-size: 20px; text-align: center;">No result Found</div>
 <?php } ?>

            
		</div>
		<!--<div class="col-md-3">
			<div id="categories-4" class="blog_sidebar_categories">
				<h4 class="side_bar_title">Categories</h4>		
				<ul class="well">
					<li class="cat-item cat-item-19"><a href="#">Beauty</a></li>
					<li class="cat-item cat-item-11"><a href="#">Crazy</a></li>
					<li class="cat-item cat-item-14"><a href="#">DIY</a></li>
					<li class="cat-item cat-item-13"><a href="#">Emotional</a></li>
					<li class="cat-item cat-item-12"><a href="#">Fashion</a></li>
					<li class="cat-item cat-item-9"><a href="#">Food</a></li>
					<li class="cat-item cat-item-17"><a href="#">Funny</a></li>
					<li class="cat-item cat-item-10"><a href="#">Health</a></li>
					<li class="cat-item cat-item-15"><a href="#">Reason</a></li>
					<li class="cat-item cat-item-18"><a href="#">Relationship</a></li>
					<li class="cat-item cat-item-20"><a href="#">Travel</a></li>
					<li class="cat-item cat-item-1"><a href="#">Uncategorized</a></li>
					<li class="cat-item cat-item-16"><a href="#">wired</a></li>
				</ul>
			</div>
		</div>-->
    </div>
</div>

 <div class="col-md-12 col-sm-12 col-xs-12 socialsite_row">
    <div class="container">
	  <div class="col-md-12 row_sub_heading text-center">
		<h3>Testimonial</h3>
	  </div>
      <div class="row text-center">
       <div class="col-md-10 col-md-offset-1">
        <br>
        <div id="tesimonial-example-generic" class="carousel slide" data-ride="carousel">
         <ol class="carousel-indicators carousel-indicators-set">
          <li data-target="#tesimonial-example-generic" data-slide-to="0" class=""></li>
          <li data-target="#tesimonial-example-generic" data-slide-to="1" class=""></li>
          <li data-target="#tesimonial-example-generic" data-slide-to="2" class="active"></li>
         </ol>
         <div class="carousel-inner">
          <div class="item">
           <div class="testimonial-section">
            <p><b>Project:</b> Install or Replace an Asphalt Shingle Roof</p>
            <p>It is such a pleasure to be able to intelligently converse with the owner of the company who patiently explains things in such a way as to inform and put at ease. He was willing to work WITH me and that is such an unusual but very very welcome situation. He has for himself and his company very high standards of work and clean up. Everything was beyond expectation. I am singing this company's praises.</p>
            <p>Was this review helpful?   Yes , No</p>
           </div>
           <div class="testimonial-section-name">
            <img src="./assets/images/Icon-user.png" alt="testimonials in bootstrap" class="img-circle">
            -  Donna W. in Ballwin, MO
           </div>
          </div>
          <div class="item">
             <div class="testimonial-section">
            <p><b>Project:</b> Install or Replace an Asphalt Shingle Roof</p>
            <p>I can't begin to say what an excellent contractor Wil Baker (Baker Exteriors) is! Of the several roofers I asked for estimates, he was the ONLY one to point out that much of the poor condition of my roof was due to hail damage and recommend that I contact my insurance carrier. Lo and behold, they approved my claim, and Wil did the work for what insurance was willing to pay. That was huge, considering especially that the house in question was under contract to sell, and a new roof was a condition of sale! He saved me thousands of $$. Not only that the work was done quickly and of the highest quality. He even replaced soft boards, which are usually an extra with most roofers. If you need a roof replacement, Wil Baker is your man, bar none.</p>
            <p>Was this review helpful?   Yes , No</p>
           </div>
           <div class="testimonial-section-name">
            <img src="./assets/images/Icon-user.png" alt="testimonials in bootstrap" class="img-circle">
            -  David B. in Saint Louis, MO
           </div>
          </div>
          
          <div class="item active">
           <div class="testimonial-section">
            <p><b>Project:</b> Repair an Asphalt Shingle Roof</p>
            <p>I had a great experience with Baker Exteriors. He was extremely prompt, courteous and professional. Work was performed and more than met my expectations at a price that was very fair. I would definitely recommend this company.</p>
            <p>Was this review helpful?   Yes , No</p>
           </div>
           <div class="testimonial-section-name">
            <img src="./assets/images/Icon-user.png" alt="testimonials in bootstrap" class="img-circle">
            -  Bryn B. in Lake Saint Louis, MO
           </div>
          </div>
         </div>
        </div>
       </div>
      </div>
	</div>
</div>


 <div class="col-md-12 col-sm-12 col-xs-12 sec_submit_request">
    <div class="container">
        <div class="row_sub_heading text-center">
            <h3>Have more questions? Request a sales contact:</h3>
        </div>
        <div class="text-center">
            <a class="req_submit_btn" href="#">Submit Request</a>
        </div>
    </div>
</div>
</div>
</section>
<?php include 'footer.php';?>                              		