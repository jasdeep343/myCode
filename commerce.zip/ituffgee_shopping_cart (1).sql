-- phpMyAdmin SQL Dump
-- version 4.6.6
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Jun 02, 2017 at 06:25 PM
-- Server version: 5.6.35
-- PHP Version: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ituffgee_shopping_cart`
--

-- --------------------------------------------------------

--
-- Table structure for table `brand`
--

CREATE TABLE `brand` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `status` int(11) NOT NULL,
  `create_date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `brand`
--

INSERT INTO `brand` (`id`, `name`, `image`, `status`, `create_date`) VALUES
(1, 'adidas', 'adidas.jpg', 1, '2017-05-17 00:00:00'),
(2, 'gucci', 'gucci.png', 1, '2017-05-17 00:00:00'),
(3, 'reebok', 'reebok.png', 1, '2017-05-17 00:00:00'),
(4, 'adidas original', 'adidasorg.jpg', 1, '2017-05-17 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `id` int(11) NOT NULL,
  `cat_name` varchar(255) NOT NULL,
  `gender` varchar(255) NOT NULL COMMENT '1=mens,2=women,3=boy,4=girl',
  `type` int(11) NOT NULL COMMENT '1=clothing,2=footwear,3=watches,4=accesseries',
  `type_name` varchar(255) NOT NULL,
  `status` int(1) NOT NULL,
  `create_time` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`id`, `cat_name`, `gender`, `type`, `type_name`, `status`, `create_time`) VALUES
(1, 'T-Shirts', '1', 1, '', 1, '2017-02-01 00:00:00'),
(2, 'Shirts', '1', 1, '', 1, '2017-02-01 00:00:00'),
(3, 'Jeans', '1', 1, '', 1, '2017-02-01 00:00:00'),
(4, 'Trousers', '1', 1, '', 1, '2017-02-01 00:00:00'),
(5, 'Winter Wear', '1', 1, '', 1, '2017-02-01 00:00:00'),
(6, 'Sports Wear', '1', 1, '', 1, '2017-02-01 00:00:00'),
(7, 'Suits & Blazers', '1', 1, '', 1, '2017-02-01 00:00:00'),
(8, 'Innerwear & Loungewear', '1', 1, '', 1, '2017-02-01 00:00:00'),
(9, 'Ethnic Wear', '1', 1, '', 1, '2017-02-01 00:00:00'),
(10, 'Accessories', '1', 1, '', 1, '2017-02-01 00:00:00'),
(11, 'Shorts, 3/4ths & Cargos', '1', 1, '', 1, '2017-02-01 00:00:00'),
(12, 'Sports Shoes', '1', 2, '', 1, '2017-02-01 00:00:00'),
(13, 'Casual Shoes', '1', 2, '', 1, '2017-02-01 00:00:00'),
(14, 'Formal Shoes', '1', 2, '', 1, '2017-02-01 00:00:00'),
(15, 'Sandals & Floaters', '1', 2, '', 1, '2017-02-01 00:00:00'),
(16, 'Flip- Flops', '1', 2, '', 1, '2017-02-01 00:00:00'),
(17, 'Loafers', '1', 2, '', 1, '2017-02-01 00:00:00'),
(18, 'Boots', '1', 2, '', 1, '2017-02-01 00:00:00'),
(19, 'Running Shoes', '1', 2, '', 1, '2017-02-01 00:00:00'),
(20, 'Sneakers', '1', 2, '', 1, '2017-02-01 00:00:00'),
(21, 'Fastrack', '1', 3, '', 1, '2017-02-01 00:00:00'),
(22, 'Casio', '1', 3, '', 1, '2017-02-01 00:00:00'),
(23, 'Titan', '1', 3, '', 1, '2017-02-01 00:00:00'),
(24, 'Fossil', '1', 3, '', 1, '2017-02-01 00:00:00'),
(25, 'Sonata', '1', 3, '', 1, '2017-02-01 00:00:00'),
(26, 'Backpacks', '1', 4, '', 1, '2017-02-01 00:00:00'),
(27, 'Wallets', '1', 4, '', 1, '2017-02-01 00:00:00'),
(28, 'Belts', '1', 4, '', 1, '2017-02-01 00:00:00'),
(29, 'Sunglasses & Frames', '1', 4, '', 1, '2017-02-01 00:00:00'),
(30, 'Luggage & Travel', '1', 4, '', 1, '2017-02-01 00:00:00'),
(31, 'Jewellery', '1', 4, '', 1, '2017-02-01 00:00:00'),
(32, 'Trimmers', '1', 5, '', 1, '2017-02-01 00:00:00'),
(33, 'Shavers', '1', 5, '', 1, '2017-02-01 00:00:00'),
(34, 'Grooming Kits', '1', 5, '', 1, '2017-02-01 00:00:00'),
(35, 'Deodorants', '1', 6, '', 1, '2017-02-01 00:00:00'),
(36, 'Perfumes', '1', 6, '', 1, '2017-02-01 00:00:00'),
(37, 'Top, T-Shirts & Shirts', '2', 7, '', 1, '2017-02-01 00:00:00'),
(38, 'Dresses', '2', 7, '', 1, '2017-02-01 00:00:00'),
(39, 'Jeans', '2', 7, '', 1, '2017-02-01 00:00:00'),
(40, 'Trousers & Capris', '2', 7, '', 1, '2017-02-01 00:00:00'),
(41, 'Skirts', '2', 7, '', 1, '2017-02-01 00:00:00'),
(42, 'Shrugs', '2', 8, '', 1, '2017-02-01 00:00:00'),
(43, 'Sweatshirts', '2', 8, '', 1, '2017-02-01 00:00:00'),
(44, 'Sweaters', '2', 8, '', 1, '2017-02-01 00:00:00'),
(45, 'Jackets & Coats', '2', 8, '', 1, '2017-02-01 00:00:00'),
(46, 'Kurtas & Kurtis', '2', 9, '', 1, '2017-02-01 00:00:00'),
(47, 'Sarees', '2', 9, '', 1, '2017-02-01 00:00:00'),
(48, 'Dress Material', '2', 9, '', 1, '2017-02-01 00:00:00'),
(49, 'Lehenga Choli', '2', 9, '', 1, '2017-02-01 00:00:00'),
(50, 'Salwar Suits', '2', 9, '', 1, '2017-02-01 00:00:00'),
(51, 'Blouse', '2', 9, '', 1, '2017-02-01 00:00:00'),
(52, 'Leggings, Salwars & Churidars', '2', 9, '', 1, '2017-02-01 00:00:00'),
(53, 'Bras', '2', 10, '', 1, '2017-02-01 00:00:00'),
(54, 'Panties', '2', 10, '', 1, '2017-02-01 00:00:00'),
(55, 'Nightsuits & Nightdresses', '2', 10, '', 1, '2017-02-01 00:00:00'),
(56, 'Flats', '2', 11, '', 1, '2017-02-01 00:00:00'),
(57, 'Heels', '2', 11, '', 1, '2017-02-01 00:00:00'),
(58, 'Wedges', '2', 11, '', 1, '2017-02-01 00:00:00'),
(59, 'Sports Shoes', '2', 11, '', 1, '2017-02-01 00:00:00'),
(60, 'Casual Shoes', '2', 11, '', 1, '2017-02-01 00:00:00'),
(61, 'Ballerinas', '2', 11, '', 1, '2017-02-01 00:00:00'),
(62, 'Boots', '2', 11, '', 1, '2017-02-01 00:00:00'),
(63, 'Slippers & Flip- Flop\'s', '2', 11, '', 1, '2017-02-01 00:00:00'),
(64, 'Watches', '2', 12, '', 1, '2017-02-01 00:00:00'),
(65, 'Hair Straightners', '2', 13, '', 1, '2017-02-01 00:00:00'),
(66, 'Hair Dryers', '2', 13, '', 1, '2017-02-01 00:00:00'),
(67, 'Make Up', '2', 14, '', 1, '2017-02-01 00:00:00'),
(68, 'Skin Care', '2', 14, '', 1, '2017-02-01 00:00:00'),
(69, 'Hair Care', '2', 14, '', 1, '2017-02-01 00:00:00'),
(70, 'Deodorants & Perfumes', '2', 14, '', 1, '2017-02-01 00:00:00'),
(71, 'Handbags & Totes', '2', 15, '', 1, '2017-02-01 00:00:00'),
(72, 'Wallets & Belts', '2', 15, '', 1, '2017-02-01 00:00:00'),
(73, 'Sunglasses & Frames', '2', 15, '', 1, '2017-02-01 00:00:00'),
(74, 'Precious Jewellery', '2', 16, '', 1, '2017-02-01 00:00:00'),
(75, 'Artificial Jewellery', '2', 16, '', 1, '2017-02-01 00:00:00'),
(76, 'Silver Jewellery', '2', 16, '', 1, '2017-02-01 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `product_name` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `cat_id` int(11) NOT NULL,
  `brand_id` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `create_time` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `product_name`, `description`, `cat_id`, `brand_id`, `status`, `create_time`) VALUES
(1, 'T-shirt1', 'cotton1', 1, 1, 1, '2017-01-31 00:00:00'),
(2, 'T-shirt2', 'cotton2', 1, 1, 1, '2017-01-31 00:00:00'),
(10, 'T-shirt2', 'cotton2', 2, 1, 1, '2017-01-31 00:00:00'),
(11, 'formal-plain', 'cotton-mix', 2, 2, 1, '2017-01-31 00:00:00'),
(12, 'jack&jones', 'denim', 3, 2, 1, '2017-01-31 00:00:00'),
(13, 'trouser1', 'cotton ', 4, 2, 1, '2017-01-31 00:00:00'),
(14, 'trouser2', 'cotton ', 4, 3, 1, '2017-01-31 00:00:00'),
(15, 'top1', 'cotton ', 37, 3, 1, '2017-01-31 00:00:00'),
(16, 'top2', 'cotton ', 37, 3, 1, '2017-01-31 00:00:00'),
(17, 'top3', 'cotton ', 37, 1, 1, '2017-01-31 00:00:00'),
(18, 'shoes1', 'canvas', 12, 2, 1, '2017-01-31 00:00:00'),
(19, 'dress1', 'siffon', 38, 3, 1, '2017-01-31 00:00:00'),
(20, 'dress2', 'silk', 38, 1, 1, '2017-01-31 00:00:00'),
(21, 'dress3', 'silk', 38, 2, 1, '2017-01-31 00:00:00'),
(22, 'kurti1', 'silk', 46, 3, 1, '2017-01-31 00:00:00'),
(23, 'sari', 'silk', 47, 3, 1, '2017-01-31 00:00:00'),
(24, 'shrug1', 'cotton', 42, 2, 1, '2017-01-31 00:00:00'),
(25, 'shrug2', 'cotton', 42, 1, 1, '2017-01-31 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `product_detail`
--

CREATE TABLE `product_detail` (
  `id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `color` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `quantity` int(11) NOT NULL,
  `price` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `create_time` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product_detail`
--

INSERT INTO `product_detail` (`id`, `product_id`, `color`, `image`, `quantity`, `price`, `status`, `create_time`) VALUES
(1, 1, '#51222a', 'product1.jpg', 5, 5, 1, '2017-04-18 00:00:00'),
(3, 2, '#1b1b1b', 'product2.jpg', 5, 15, 1, '2017-04-18 00:00:00'),
(4, 10, '#d0cc9d', 'product_2_4.jpeg', 10, 15, 1, '2017-04-18 00:00:00'),
(5, 11, '#f5f5f5', 'shirt_1.jpg', 10, 1000, 1, '2017-04-18 00:00:00'),
(6, 11, '#dee0ec', 'shirt_1_1.jpg', 10, 1000, 1, '2017-04-18 00:00:00'),
(7, 11, '#c1c3d2', 'shirt_1_2.jpg', 10, 1000, 1, '2017-04-18 00:00:00'),
(8, 11, '#dae0f6', 'shirt_1_3.jpg', 10, 1000, 1, '2017-04-18 00:00:00'),
(9, 12, '#777', 'jack.jpg', 10, 1000, 1, '2017-04-18 00:00:00'),
(10, 13, '#4f4c3d', 'Green-Slim-Trousers_1.jpg', 10, 1000, 1, '2017-04-18 00:00:00'),
(11, 13, '#fcfaee', 'Green-Slim-Trousers_1_2.jpg', 10, 1033, 1, '2017-04-18 00:00:00'),
(12, 14, '#222126', 'Linen-Casual-Trousers_1.jpg', 10, 1899, 1, '2017-04-18 00:00:00'),
(13, 14, '#665d54', 'Linen-Casual-Trousers_1_2.jpg', 10, 1000, 1, '2017-04-18 00:00:00'),
(14, 15, '#282842', 'top_1.jpg', 8, 1000, 1, '2017-04-18 00:00:00'),
(15, 16, '#b1161a', 'top_2.jpg', 10, 1500, 1, '2017-04-18 00:00:00'),
(16, 17, '#f26d5a', 'top_3.jpg', 10, 1000, 1, '2017-04-18 00:00:00'),
(17, 18, '#317fc7', 'sports_shoes_nike_1.jpeg', 10, 1000, 1, '2017-04-18 00:00:00'),
(18, 18, '#e5f6a6', 'sports_shoes_nike_1_2.jpeg', 10, 2800, 1, '2017-04-18 00:00:00'),
(19, 18, '#df4649', 'sports_shoes_nike_1_3.jpeg', 10, 3000, 1, '2017-04-18 00:00:00'),
(20, 18, '#282828', 'sports_shoes_nike_1_4.jpeg', 10, 1000, 1, '2017-04-18 00:00:00'),
(21, 19, '#f18b63', 'kurti_printed_1_2.jpg', 10, 2000, 1, '2017-04-18 00:00:00'),
(22, 20, '#77212a', 'kurti_printed_1.jpg', 10, 2300, 1, '2017-04-18 00:00:00'),
(23, 21, '#332b20', 'kurti_2.jpg', 10, 2300, 1, '2017-04-18 00:00:00'),
(24, 22, '#267fe3', 'kurti_1.jpg', 10, 2300, 1, '2017-04-18 00:00:00'),
(25, 22, '#2b2e35', 'kurti_1_2.jpg', 10, 2400, 1, '2017-04-18 00:00:00'),
(26, 22, '#882b46', 'kurti_1_3.jpg', 10, 2500, 1, '2017-04-18 00:00:00'),
(28, 23, '#ea7f70', 'sari.jpg', 10, 4000, 1, '2017-04-18 00:00:00'),
(29, 24, '#1e1fe0', 'Women-Shrug_1.jpg', 10, 900, 1, '2017-04-18 00:00:00'),
(30, 24, '#f7e8b1', 'Women-Shrug_1_2.jpg', 10, 900, 1, '2017-04-18 00:00:00'),
(31, 24, '#94e2e4', 'Women-Shrug_1_3.jpg', 10, 900, 1, '2017-04-18 00:00:00'),
(32, 25, '#1a1f35', 'DressBerry-Black-Shrug_1_2.jpg', 10, 500, 1, '2017-04-18 00:00:00'),
(33, 25, '#aaa9a4', 'DressBerry-Black-Shrug_1_3.jpg', 10, 500, 1, '2017-04-18 00:00:00'),
(34, 25, '#0d0c0a', 'DressBerry-Black-Shrug_1.jpg', 10, 500, 1, '2017-04-18 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_delivery_address`
--

CREATE TABLE `tbl_delivery_address` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `phone` bigint(100) DEFAULT NULL,
  `pincode` int(11) DEFAULT NULL,
  `building_name` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `state` varchar(255) DEFAULT NULL,
  `landmark` varchar(255) DEFAULT NULL,
  `status` int(1) DEFAULT NULL,
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_delivery_address`
--

INSERT INTO `tbl_delivery_address` (`id`, `user_id`, `name`, `phone`, `pincode`, `building_name`, `address`, `city`, `state`, `landmark`, `status`, `create_time`) VALUES
(1, 1, 'jasdeep', 123, 123, '123', '123', '123', '123', '123', 1, '2017-05-06 10:56:13'),
(2, 1, 'jasdeep', 123, 123, '123', '123', '123', '123', '123', 1, '2017-05-06 10:56:13'),
(3, 1, 'jasdeep', 1234, 1234, 'gd', 'g', 'gfd', 'gfd', 'fgd', 1, '2017-05-08 18:36:40'),
(4, 6, 'aaaa', 8888, 88888, 'aaaa', 'aaaaa', 'aaa', 'aaaa', 'aaa', 1, '2017-05-08 23:04:59'),
(5, 14, 'himanshi', 1234567890, 123456, 'talwar niwas', 'zirakpur house no300', 'zirakpur', 'chandigrh', 'uyuyu', 1, '2017-05-11 11:54:10'),
(6, 3, 'hgfhf', 1111111111, 111111, 'hgh', 'hg', 'hgfhf', 'hfg', 'h', 1, '2017-05-11 12:31:43'),
(7, 16, 'himanshi', 123456789, 123456, 'tuffgeekers', 'mohali', 'mohali', 'punjab', 'stadium', 1, '2017-05-12 14:28:07'),
(8, 1, 'jasdeep', 9034162706, 135001, 'model town', '123', 'ynr', 'hr', 'metro', 1, '2017-05-15 13:10:28'),
(9, 1, 'test', 3143232332, 122345, 'ghfgh', 'hf', 'hgf', 'hf', 'hfg', 1, '2017-05-15 13:11:40'),
(10, 18, 'geetu', 6787676768, 123456, 'talwar niwas', 'ynr sec15', 'yamunanagar', 'haryana', 'bbbmbnm', 1, '2017-05-16 17:30:54'),
(11, 19, 'pri', 9896123456, 123456, 'abcd', 'mohali', 'mohali', 'punjab', 'mohali', 1, '2017-05-25 09:32:32');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_size`
--

CREATE TABLE `tbl_size` (
  `id` int(11) NOT NULL,
  `detail_id` int(11) NOT NULL,
  `size` varchar(11) NOT NULL COMMENT '1=XL2=L',
  `status` int(11) NOT NULL,
  `create_time` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_size`
--

INSERT INTO `tbl_size` (`id`, `detail_id`, `size`, `status`, `create_time`) VALUES
(1, 1, 'xl', 1, '2017-04-18 00:00:00'),
(2, 1, 'l', 1, '2017-04-18 00:00:00'),
(3, 2, 'xxl', 1, '2017-04-18 00:00:00'),
(4, 3, 'l', 1, '2017-04-18 00:00:00'),
(5, 4, 'l', 1, '2017-04-18 00:00:00'),
(6, 5, 'l', 1, '2017-04-18 00:00:00'),
(7, 5, 'XL', 1, '2017-04-18 00:00:00'),
(8, 5, 'XXL', 1, '2017-04-18 00:00:00'),
(9, 6, 'L', 1, '2017-04-18 00:00:00'),
(10, 6, 'XL', 1, '2017-04-18 00:00:00'),
(11, 7, 'XL', 1, '2017-04-18 00:00:00'),
(12, 8, 'L', 1, '2017-04-18 00:00:00'),
(13, 8, 'XXL', 1, '2017-04-18 00:00:00'),
(14, 9, '34', 1, '2017-04-18 00:00:00'),
(15, 9, '36', 1, '2017-04-18 00:00:00'),
(16, 9, '32', 1, '2017-04-18 00:00:00'),
(17, 10, '32', 1, '2017-04-18 00:00:00'),
(18, 11, '32', 1, '2017-04-18 00:00:00'),
(19, 11, '34', 1, '2017-04-18 00:00:00'),
(20, 12, '34', 1, '2017-04-18 00:00:00'),
(21, 13, '34', 1, '2017-04-18 00:00:00'),
(22, 14, 'xl', 1, '2017-04-18 00:00:00'),
(23, 15, 'xl', 1, '2017-04-18 00:00:00'),
(24, 15, 'l', 1, '2017-04-18 00:00:00'),
(25, 16, 'l', 1, '2017-04-18 00:00:00'),
(26, 17, '8', 1, '2017-04-18 00:00:00'),
(27, 18, '7', 1, '2017-04-18 00:00:00'),
(28, 19, '8', 1, '2017-04-18 00:00:00'),
(29, 20, '7', 1, '2017-04-18 00:00:00'),
(31, 21, 'm', 1, '2017-04-18 00:00:00'),
(30, 22, 'm', 1, '2017-04-18 00:00:00'),
(32, 23, 'm', 1, '2017-04-18 00:00:00'),
(33, 23, 'l', 1, '2017-04-18 00:00:00'),
(34, 24, 'l', 1, '2017-04-18 00:00:00'),
(35, 25, 'xl', 1, '2017-04-18 00:00:00'),
(36, 25, 'l', 1, '2017-04-18 00:00:00'),
(37, 26, 'm', 1, '2017-04-18 00:00:00'),
(38, 27, 'l', 1, '2017-04-18 00:00:00'),
(39, 28, '5.5m', 1, '2017-04-18 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `_tbl_order`
--

CREATE TABLE `_tbl_order` (
  `order_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `product_detail_id` int(11) NOT NULL,
  `address_id` int(11) NOT NULL,
  `size` varchar(100) NOT NULL,
  `qty` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `price` int(100) NOT NULL,
  `color_id` int(11) NOT NULL,
  `status` int(1) NOT NULL,
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `_tbl_order`
--

INSERT INTO `_tbl_order` (`order_id`, `user_id`, `product_id`, `product_detail_id`, `address_id`, `size`, `qty`, `name`, `price`, `color_id`, `status`, `create_time`) VALUES
(1, 1, 1, 15, 9, 'l', 1, 'top2', 1500, 15, 0, '2017-05-15 18:00:06'),
(2, 1, 1, 3, 9, 'l', 1, 'T-shirt2', 15, 3, 0, '2017-05-15 18:00:06'),
(3, 18, 1, 21, 10, 'm', 1, 'dress1', 2000, 21, 0, '2017-05-16 17:31:17'),
(4, 1, 1, 1, 1, 'xl', 1, 'T-shirt1', 5, 1, 0, '2017-05-17 10:44:32'),
(5, 1, 1, 1, 9, '', 1, 'T-shirt1', 5, 1, 0, '2017-05-17 21:13:18'),
(6, 1, 1, 1, 9, '', 1, 'T-shirt1', 5, 1, 0, '2017-05-17 21:18:52'),
(7, 1, 1, 1, 9, 'xl', 1, 'T-shirt1', 5, 1, 0, '2017-05-17 21:18:52'),
(8, 1, 1, 1, 9, '', 1, 'T-shirt1', 5, 1, 0, '2017-05-17 21:24:05'),
(9, 1, 1, 1, 9, 'xl', 1, 'T-shirt1', 5, 1, 0, '2017-05-17 21:24:05'),
(10, 19, 1, 3, 11, 'l', 1, 'T-shirt2', 15, 3, 0, '2017-05-25 09:32:54');

-- --------------------------------------------------------

--
-- Table structure for table `_tbl_users`
--

CREATE TABLE `_tbl_users` (
  `id` int(11) NOT NULL,
  `F_name` varchar(255) DEFAULT NULL,
  `L_name` varchar(255) DEFAULT NULL,
  `E_mail` varchar(255) DEFAULT NULL,
  `P_wrd` varchar(255) DEFAULT NULL,
  `P_image` varchar(255) DEFAULT NULL,
  `P_status` int(1) DEFAULT NULL,
  `Created_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `_tbl_users`
--

INSERT INTO `_tbl_users` (`id`, `F_name`, `L_name`, `E_mail`, `P_wrd`, `P_image`, `P_status`, `Created_time`) VALUES
(1, 'jasdeep', 'singh', 'email@gmail.com', '202cb962ac59075b964b07152d234b70', 'user.png', 1, '2017-04-29 00:00:00'),
(2, NULL, NULL, 'asd@sds.fdd', '202cb962ac59075b964b07152d234b70', 'default.png', NULL, '2017-05-05 17:33:18'),
(3, NULL, NULL, 'email2@gmail.com', '202cb962ac59075b964b07152d234b70', 'default.png', 1, '2017-05-05 17:53:54'),
(4, NULL, NULL, 'email3@gmail.com', '202cb962ac59075b964b07152d234b70', 'default.png', 1, '2017-05-05 17:54:53'),
(5, NULL, NULL, 'email4@gmail.com', '202cb962ac59075b964b07152d234b70', 'default.png', 1, '2017-05-05 17:57:10'),
(6, NULL, NULL, 'himanshituffgeekers@gmail.com', 'ca029293bddb0a46bc0804c348caa22e', 'default.png', 1, '2017-05-05 18:02:25'),
(7, NULL, NULL, 'himanshituffgeekers@gmail.com', 'ca029293bddb0a46bc0804c348caa22e', 'default.png', 1, '2017-05-05 18:02:36'),
(8, NULL, NULL, 'jljkjkjkj', '93164f1a5b394f9cc5bb090cde02c519', 'default.png', 1, '2017-05-05 18:07:56'),
(9, NULL, NULL, 'email!23@gmail.com', '202cb962ac59075b964b07152d234b70', 'default.png', 1, '2017-05-05 18:13:11'),
(10, NULL, NULL, 'nishu@gmail.com', '81dc9bdb52d04dc20036dbd8313ed055', 'default.png', 1, '2017-05-10 08:05:55'),
(11, NULL, NULL, 'dishu@gmail.com', 'f20b32b39a99a2931c88ee90bff8366a', 'default.png', 1, '2017-05-10 12:36:11'),
(12, NULL, NULL, 'prakash.tuffgeekers@gmail.com', '79bd2b6b389ee211aaf26e9ea3a1292e', 'default.png', 1, '2017-05-10 12:44:08'),
(13, NULL, NULL, 'admin@gmail.com', '202cb962ac59075b964b07152d234b70', 'default.png', 1, '2017-05-10 15:43:52'),
(14, NULL, NULL, 'new_email@gmail.com', 'ac32851aff82e201c10cb426af724fbf', 'default.png', 1, '2017-05-11 11:53:02'),
(15, NULL, NULL, 'h@gmail.com', '81dc9bdb52d04dc20036dbd8313ed055', 'default.png', 1, '2017-05-11 18:10:47'),
(16, NULL, NULL, 'himanshi.tuffgeekers@gmail.com', 'd0dc7cc4f554e07f308b824d63feb95b', 'default.png', 1, '2017-05-12 14:25:35'),
(17, NULL, NULL, 'new@gmail.com', '22af645d1859cb5ca6da0c484f1f37ea', 'default.png', 1, '2017-05-15 09:32:15'),
(18, NULL, NULL, 'geetu@gmail.com', '39817ddd223b054601de6bdd2e2f4742', 'default.png', 1, '2017-05-16 17:28:46'),
(19, NULL, NULL, 'priyanka.tuffgeekers@gmail.com', '807ea7193e79ec8cf37728b167c3682a', 'default.png', 1, '2017-05-25 09:30:43');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `brand`
--
ALTER TABLE `brand`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product_detail`
--
ALTER TABLE `product_detail`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_delivery_address`
--
ALTER TABLE `tbl_delivery_address`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_size`
--
ALTER TABLE `tbl_size`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `_tbl_order`
--
ALTER TABLE `_tbl_order`
  ADD PRIMARY KEY (`order_id`);

--
-- Indexes for table `_tbl_users`
--
ALTER TABLE `_tbl_users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `brand`
--
ALTER TABLE `brand`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=77;
--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;
--
-- AUTO_INCREMENT for table `product_detail`
--
ALTER TABLE `product_detail`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;
--
-- AUTO_INCREMENT for table `tbl_delivery_address`
--
ALTER TABLE `tbl_delivery_address`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT for table `tbl_size`
--
ALTER TABLE `tbl_size`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;
--
-- AUTO_INCREMENT for table `_tbl_order`
--
ALTER TABLE `_tbl_order`
  MODIFY `order_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `_tbl_users`
--
ALTER TABLE `_tbl_users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
