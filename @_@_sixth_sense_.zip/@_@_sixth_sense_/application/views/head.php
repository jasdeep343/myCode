    <link href="http://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700" rel="stylesheet" type="text/css">

    <link href="<?php  echo base_url(); ?>assets/css/bootstrap.min.css" rel="stylesheet">

    <link href="<?php  echo base_url(); ?>assets/css/font-awesome.min.css" rel="stylesheet">

    <link href="<?php  echo base_url(); ?>assets/css/style.css" rel="stylesheet">

    <script src="<?php  echo base_url(); ?>assets/js/jquery.min.js" type="text/javascript"></script>

    <script src="<?php  echo base_url(); ?>assets/js/bootstrap.min.js" type="text/javascript"></script>

	<script src="<?php  echo base_url(); ?>assets/js/angular.min.js" type="text/javascript"></script>

	<script src="<?php  echo base_url(); ?>assets/js/function.js" type="text/javascript"></script>

	<script> var BASE_URL = "<?php echo base_url(); ?>" ;</script>

<script>
/*document.onkeydown = function(e) {
        if (e.ctrlKey && 
            (e.keyCode === 67 || 
             e.keyCode === 86 || 
             e.keyCode === 85 || 
             e.keyCode === 117)) {
            alert('not allowed');
            return false;
        } else {
            return true;
        }
};

$(document).on("contextmenu",function(e){        
   e.preventDefault();
});

$(document).keydown(function(event){
    if(event.keyCode==123){
    return false;
   }
else if(event.ctrlKey && event.shiftKey && event.keyCode==73){        
      return false;  //Prevent from ctrl+shift+i
   }
});*/

</script>
