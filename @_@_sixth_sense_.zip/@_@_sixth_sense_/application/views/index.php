<!DOCTYPE html>
<head>
    <meta http-equiv="content-type" content="text/html;charset=UTF-8">
    <meta content="width=device-width, initial-scale=1, maximum-scale=1" name="viewport">
    <meta content="text/html; charset=UTF-8" http-equiv="Content-Type">
    <title>Login</title>
    <?php include("head.php");?>

 </head>
<body>
	<div class="login_index">
		<div class="container">
			<div class="hand_sec">
				<img class="img-responsive" src="<?php  echo base_url(); ?>assets/images/main-hand.png">
				<button class="left_btn_iris"><img class="" src="<?php  echo base_url(); ?>assets/images/iris.png"></button>
				<button class="img_btn left_btn_1" id="left_btn_1" onclick="addSence('left_btn_1','ear');"><img class="icon-1" src="<?php  echo base_url(); ?>assets/images/hex-ear.png"></button>
				<button class="img_btn left_btn_2" id="left_btn_2" onclick="addSence('left_btn_2','eye');"><img class="icon-2" src="<?php  echo base_url(); ?>assets/images/hex-eye.png"></button>
				<button class="img_btn left_btn_3" id="left_btn_3" onclick="addSence('left_btn_3','Nose');"><img class="icon-2" src="<?php  echo base_url(); ?>assets/images/hex-Nose.png"></button>
				<button class="img_btn left_btn_4" id="left_btn_4" onclick="addSence('left_btn_4','hand');"><img class="icon-2" src="<?php  echo base_url(); ?>assets/images/hex-hand.png"></button>
				<button class="img_btn left_btn_5" id="left_btn_5" onclick="addSence('left_btn_5','mouth');"><img class="icon-2" src="<?php  echo base_url(); ?>assets/images/hex-mouth.png"></button>
			</div>
			<button class="img_btn left_btn" onclick="accessCode();"><img height="auto" src="<?php  echo base_url(); ?>assets/images/Get-access-code.png"></button>
			<input class="input_user" id="user_email" type="text" placeholder="Username">
			<button class="img_btn right_btn"><img height="auto" src="<?php  echo base_url(); ?>assets/images/Enter-access-code.png"></button>
			<button class="img_btn btn_email"><img class="icon-2" src="<?php  echo base_url(); ?>assets/images/hex-email.png"></button>
			<div class="bottom_sec">
				
				<div class="password_sec">
					<div class="set_password password_1" id="password_1">
						<div id="empty_1"></div>
						<svg version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="54.59px" height="99.306px" viewBox="0 0 87.59 99.306" enable-background="new 0 0 87.59 99.306" xml:space="preserve" style="display: none;">
						<g>
							<path stroke="#008f97" stroke-miterlimit="10" d="
							M45.377,98.392c-0.953,
							0.55-2.513,0.552-3.467,
							0.005l-39.68-22.75	c-0.954-0.547-1.732-1.895-1.729-2.995l0.139-45.739c0.003-1.1,
							0.785-2.45,1.738-3l39.837-23c0.953-0.55,
							2.513-0.552,3.467-0.005
							l39.68,22.75c0.954,
							0.547,1.732,
							1.895,1.729,
							2.995l-0.139,
							45.739c-0.003,
							1.1-0.785,
							2.45-1.738,
							3L45.377,98.392z
							"></path>	
						</g>
						</svg>
					</div>
					<div class="set_password password_2" id="password_2">
						<div id="empty_2"></div>
						<svg id="line_2" width="50" height="80" viewBox="0 0 120 120" xmlns="http://www.w3.org/2000/svg" style="display: none;">
							<line x1="-40" y1="202" x2="150" y2="102" style="stroke:#008f97;stroke-width:4"></line>
						</svg>	
						<svg version="1.1" id="Layer_2" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="54.59px" height="99.306px" viewBox="0 0 87.59 99.306" enable-background="new 0 0 87.59 99.306" xml:space="preserve" style="display: none;">
						<g>
							<path stroke="#008f97" stroke-miterlimit="10" d="
							M45.377,98.392c-0.953,
							0.55-2.513,0.552-3.467,
							0.005l-39.68-22.75	c-0.954-0.547-1.732-1.895-1.729-2.995l0.139-45.739c0.003-1.1,
							0.785-2.45,1.738-3l39.837-23c0.953-0.55,
							2.513-0.552,3.467-0.005
							l39.68,22.75c0.954,
							0.547,1.732,
							1.895,1.729,
							2.995l-0.139,
							45.739c-0.003,
							1.1-0.785,
							2.45-1.738,
							3L45.377,98.392z
							"></path>
						</g>
						
						</svg>			
					</div> 
					<div class="set_password password_3" id="password_3">
						<div id="empty_3"></div>
						<svg id="line_3" width="30" height="80" viewBox="0 0 120 120" xmlns="http://www.w3.org/2000/svg" style="display: none;">
							<line x1="3" y1="-19" x2="1122" y2="583" style="stroke:#008f97;stroke-width:7"></line>
						</svg>	
						<svg version="1.1" id="Layer_3" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="54.59px" height="99.306px" viewBox="0 0 87.59 99.306" enable-background="new 0 0 87.59 99.306" xml:space="preserve" style="display: none;">
						<g>
							<path stroke="#008f97" stroke-miterlimit="10" d="
							M45.377,98.392c-0.953,
							0.55-2.513,0.552-3.467,
							0.005l-39.68-22.75	c-0.954-0.547-1.732-1.895-1.729-2.995l0.139-45.739c0.003-1.1,
							0.785-2.45,1.738-3l39.837-23c0.953-0.55,
							2.513-0.552,3.467-0.005
							l39.68,22.75c0.954,
							0.547,1.732,
							1.895,1.729,
							2.995l-0.139,
							45.739c-0.003,
							1.1-0.785,
							2.45-1.738,
							3L45.377,98.392z
							"></path>
						</g>
						</svg>					
					</div>
					<div class="set_password password_4" id="password_4">
						<div id="empty_4"></div>
						<svg id="line_4" width="30" height="80" viewBox="0 0 120 120" xmlns="http://www.w3.org/2000/svg" style="display: none;">
							<line x1="3" y1="-19" x2="1122" y2="583" style="stroke:#008f97;stroke-width:7"></line>
						</svg>
						<svg version="1.1" id="Layer_4" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="54.59px" height="99.306px" viewBox="0 0 87.59 99.306" enable-background="new 0 0 87.59 99.306" xml:space="preserve" style="display: none;">
						<g>
							<path stroke="#008f97" stroke-miterlimit="10" d="
							M45.377,98.392c-0.953,
							0.55-2.513,0.552-3.467,
							0.005l-39.68-22.75	c-0.954-0.547-1.732-1.895-1.729-2.995l0.139-45.739c0.003-1.1,
							0.785-2.45,1.738-3l39.837-23c0.953-0.55,
							2.513-0.552,3.467-0.005
							l39.68,22.75c0.954,
							0.547,1.732,
							1.895,1.729,
							2.995l-0.139,
							45.739c-0.003,
							1.1-0.785,
							2.45-1.738,
							3L45.377,98.392z
							"></path>
						</g>
						</svg>
					<svg id="line_82" width="50" height="50" viewBox="0 0 120 111" xmlns="http://www.w3.org/2000/svg" style="display: none;">
							<line x1="14" y1="0" x2="100" y2="58" style="stroke:#008f97;stroke-width:4"></line>
						</svg>		
						<div id="empty_10" style="display: none;">
							<!--img src="<?php  echo base_url(); ?>assets/images/Layer22.png"-->
							<p>SIXTH SENSE</p>
						</div>	
					</div>
					<div class="set_password password_5" id="password_5">
						<div id="empty_5"></div>
						<svg id="line_5" width="50" height="80" viewBox="0 0 120 120" xmlns="http://www.w3.org/2000/svg" style="display: none;">
							<line x1="-40" y1="202" x2="150" y2="102" style="stroke:#008f97;stroke-width:4"></line>
						</svg>
						<svg version="1.1" id="Layer_5" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="54.59px" height="99.306px" viewBox="0 0 87.59 99.306" enable-background="new 0 0 87.59 99.306" xml:space="preserve" style="display: none;">
						<g>
							<path stroke="#008f97" stroke-miterlimit="10" d="
							M45.377,98.392c-0.953,
							0.55-2.513,0.552-3.467,
							0.005l-39.68-22.75	c-0.954-0.547-1.732-1.895-1.729-2.995l0.139-45.739c0.003-1.1,
							0.785-2.45,1.738-3l39.837-23c0.953-0.55,
							2.513-0.552,3.467-0.005
							l39.68,22.75c0.954,
							0.547,1.732,
							1.895,1.729,
							2.995l-0.139,
							45.739c-0.003,
							1.1-0.785,
							2.45-1.738,
							3L45.377,98.392z
							"></path>
						</g>
						</svg>
					</div>
					<div class="set_password password_6" id="password_6">
						<div id="empty_6"></div>
						<svg id="line_6" width="30" height="80" viewBox="0 0 120 120" xmlns="http://www.w3.org/2000/svg" style="display: none;">
							<line x1="3" y1="-19" x2="1122" y2="583" style="stroke:#008f97;stroke-width:7"></line>
						</svg>
						<svg version="1.1" id="Layer_6" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="54.59px" height="99.306px" viewBox="0 0 87.59 99.306" enable-background="new 0 0 87.59 99.306" xml:space="preserve" style="display: none;">
						<g>
							<path stroke="#008f97" stroke-miterlimit="10" fill="url(#empty_6)" d="
							M45.377,98.392c-0.953,
							0.55-2.513,0.552-3.467,
							0.005l-39.68-22.75	c-0.954-0.547-1.732-1.895-1.729-2.995l0.139-45.739c0.003-1.1,
							0.785-2.45,1.738-3l39.837-23c0.953-0.55,
							2.513-0.552,3.467-0.005
							l39.68,22.75c0.954,
							0.547,1.732,
							1.895,1.729,
							2.995l-0.139,
							45.739c-0.003,
							1.1-0.785,
							2.45-1.738,
							3L45.377,98.392z
							"></path>
						</g>
						</svg>
					</div>
					<div class="set_password password_7" id="password_7">
						<div id="empty_7"></div>
						<svg id="line_7" width="50" height="80" viewBox="0 0 120 120" xmlns="http://www.w3.org/2000/svg" style="display: none;">
							<line x1="-40" y1="202" x2="150" y2="102" style="stroke:#008f97;stroke-width:4"></line>
						</svg>
						<svg version="1.1" id="Layer_7" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="54.59px" height="99.306px" viewBox="0 0 87.59 99.306" enable-background="new 0 0 87.59 99.306" xml:space="preserve" style="display: none;">
						<g>
							<path stroke="#008f97" stroke-miterlimit="10" fill="url(#empty_7)" d="
							M45.377,98.392c-0.953,
							0.55-2.513,0.552-3.467,
							0.005l-39.68-22.75	c-0.954-0.547-1.732-1.895-1.729-2.995l0.139-45.739c0.003-1.1,
							0.785-2.45,1.738-3l39.837-23c0.953-0.55,
							2.513-0.552,3.467-0.005
							l39.68,22.75c0.954,
							0.547,1.732,
							1.895,1.729,
							2.995l-0.139,
							45.739c-0.003,
							1.1-0.785,
							2.45-1.738,
							3L45.377,98.392z
							"></path>
						</g>
						</svg>
					</div>
					<div class="set_password password_checkbox">
						<!--button class="checkbox_btn"><img class="clear_img" src="<?php  echo base_url(); ?>assets/images/checkbox.png"></button-->
						<div id="empty_9" style="display: none;">
							<button class="checkbox_btn"><img id="checkbox" class="clear_img" src="<?php  echo base_url(); ?>assets/images/checkbox.png" style="display: none;"></button>
						</div>
						<svg id="line_83" width="50" height="80" viewBox="0 0 120 120" xmlns="http://www.w3.org/2000/svg" style="display: none;">
							<line x1="-40" y1="202" x2="150" y2="107" style="stroke:#008f97;stroke-width:4"></line>
						</svg>
						<svg version="1.1" id="Layer_11" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="30px" height="30px" viewBox="0 0 87.59 99.306" enable-background="new 0 0 87.59 99.306" xml:space="preserve" style="display: none;">
						<g>
							<path stroke="#008f97" stroke-miterlimit="10" d="
							M45.377,98.392c-0.953,
							0.55-2.513,0.552-3.467,
							0.005l-39.68-22.75	c-0.954-0.547-1.732-1.895-1.729-2.995l0.139-45.739c0.003-1.1,
							0.785-2.45,1.738-3l39.837-23c0.953-0.55,
							2.513-0.552,3.467-0.005
							l39.68,22.75c0.954,
							0.547,1.732,
							1.895,1.729,
							2.995l-0.139,
							45.739c-0.003,
							1.1-0.785,
							2.45-1.738,
							3L45.377,98.392z
							"></path>
						</g>
						</svg>
					</div>
					
					<div class="set_password password_clear" id="">
						<div id="empty_8" style="display: none;">
							<button class="clear_btn" id="clear_all" onclick="clearAll();">
								<img id="img_close" class="clear_img" src="<?php  echo base_url(); ?>assets/images/clear.png" style="display: none;">
							</button>
						</div>
						<svg id="line_81" width="30" height="80" viewBox="0 0 120 120" xmlns="http://www.w3.org/2000/svg" style="display: none;">
							<line x1="3" y1="-19" x2="1122" y2="583" style="stroke:#008f97;stroke-width:7"></line>
						</svg>
						<svg version="1.1" id="Layer_10" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="30px" height="30px" viewBox="0 0 87.59 99.306" enable-background="new 0 0 87.59 99.306" xml:space="preserve" style="display: none;">
						<g>
							<path stroke="#008f97" stroke-miterlimit="10" d="
							M45.377,98.392c-0.953,
							0.55-2.513,0.552-3.467,
							0.005l-39.68-22.75	c-0.954-0.547-1.732-1.895-1.729-2.995l0.139-45.739c0.003-1.1,
							0.785-2.45,1.738-3l39.837-23c0.953-0.55,
							2.513-0.552,3.467-0.005
							l39.68,22.75c0.954,
							0.547,1.732,
							1.895,1.729,
							2.995l-0.139,
							45.739c-0.003,
							1.1-0.785,
							2.45-1.738,
							3L45.377,98.392z
							"></path>
						</g>
						
						</svg>			
					</div>
				</div>
				<div id="drawing"></div>
				<div class="overlay_div"></div>
			</div>
		</div>
	</div>

</body></html><script>$( document ).ready(function() {//$('.clear_btn').hide();//$('.checkbox_btn').hide();$('#Layer_1').css('display','none');$('#Layer_2').css('display','none');$('#Layer_3').css('display','none');$('#Layer_4').css('display','none');$('#Layer_5').css('display','none');$('#Layer_6').css('display','none');$('#Layer_7').css('display','none');$('#Layer_10').css('display','none');$('#Layer_11').css('display','none');$('#empty_8').css('display','none');$('#empty_9').css('display','none');$('#empty_10').css('display','none');$('#line_2').css('display','none');$('#line_3').css('display','none');$('#line_4').css('display','none');$('#line_5').css('display','none');$('#line_6').css('display','none');$('#line_7').css('display','none');$('#img_close').css('display','none');$('#checkbox').css('display','none');$('#line_81').css('display','none');$('#line_82').css('display','none');$('#line_83').css('display','none');});function addSence(id,image){	for (i = 1; i <= 7; i++) {		if ($('#empty_'+i).is(':empty')){			var img = document.createElement("IMG");				img.src = "images/"+image+".png";				img.setAttribute("id", "demoid"+i);				document.getElementById('empty_'+i).appendChild(img);				//$("#empty_1").delay(1500).fadeIn();				if(i == 1){					$("#empty_8").delay(3000).fadeIn();					$('#img_close').css('display','block');					$('#line_81').css('display','block');					$('#Layer_10').css('display','block');					//$('#empty_8').show();				}				if(i == 4){					$("#empty_10").delay(3000).fadeIn();					$('#line_82').css('display','block');					//$('#empty_10').show();				}				if(i == 5){					$("#empty_9").delay(3000).fadeIn();					$('#checkbox').css('display','block');					$('#line_83').css('display','block');					$('#Layer_11').css('display','block');					//$('#empty_9').show();				}				$('#Layer_'+i).css('display','block');				$('#line_'+i).css('display','block');		break;		}		}}function clearAll(){for (i = 1; i <= 7; i++) {		$('#demoid'+i).remove();		$('#Layer_'+i).css('display','none');		$('#line_'+i).css('display','none');		//$('#empty_'+i).css('display','none');	   /*$('#password_'+i).empty();	*/	}	//$("#empty_8").delay(3000).fadeIn();	$('#img_close').css('display','none');	$('#checkbox').css('display','none');	$('#line_81').css('display','none');	$('#line_82').css('display','none');	$('#line_83').css('display','none');	$('#empty_10').css('display','none');	$('#Layer_10').css('display','none');	$('#Layer_11').css('display','none');}$(".img_btn.right_btn").click(function(){	setTimeout(function(){	   $(".login_index").addClass("move");   });});/*$(".right_btn").click(function(){	setTimeout(function(){	   $(".overlay_div").addClass("info_active");   }, 100);});*/</script>