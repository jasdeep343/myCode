<!DOCTYPE html>

<head>

    <meta http-equiv="content-type" content="text/html;charset=UTF-8">

    <meta content="width=device-width, initial-scale=1, maximum-scale=1" name="viewport">

    <meta content="text/html; charset=UTF-8" http-equiv="Content-Type">

    <title>Dashboard</title>

    <link href="http://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700" rel="stylesheet" type="text/css">

    <link href="<?php  echo base_url(); ?>assets/css/bootstrap.min.css" rel="stylesheet">

    <link href="<?php  echo base_url(); ?>assets/css/font-awesome.min.css" rel="stylesheet">

    <link href="<?php  echo base_url(); ?>assets/css/style.css" rel="stylesheet">

    <script src="<?php  echo base_url(); ?>assets/js/jquery.min.js" type="text/javascript"></script>

    <script src="<?php  echo base_url(); ?>assets/js/bootstrap.min.js" type="text/javascript"></script>

</head>

<body>

	<div class="login_index">

    	<a href="<?php echo base_url(); ?>home/logout" class="logout">Logout</a>

		<div class="container">

			<div class="add-email-section">

            	<div class="add-box">

                	<table class="table-style">
                    	<thead>
                        	<tr>
                            	<th> &nbsp;&nbsp;</th>
                            	<th width="12%">Id</th>
                                <th width="59%">EMail</th>
                                <th width="35%">Sense Code</th>
                            </tr>
                        </thead>
                        <tbody class="td-style">    
                            
                            <?php
                            if(!empty($ShowAllUsers)){
								foreach($ShowAllUsers as $key=>$val){
                            ?>
                            <tr>
                                <td><input type="radio" value="1" name="select"> </td>
                                <td><?php echo $val['id']; ?></td>
                                <td><?php echo $val['email']; ?></td>
                                <td><?php echo $val['access_code']; ?></td>
                             </tr>
                            <?php } } ?>
 
                        </tbody>	
                     </table>
                 </div>
             </div>
			 <div class="bottom_sec">

				<!--img class="bottom_btns" src="<?php  echo base_url(); ?>assets/images/Password.png"-->

				<div class="password_sec">

					<div class="set_password password_1" id="password_1">

						<div id="empty_1"></div>

						<svg version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="54.59px" height="99.306px" viewBox="0 0 87.59 99.306" enable-background="new 0 0 87.59 99.306" xml:space="preserve" style="display: none;">

						<g>

							<path stroke="#008f97" stroke-miterlimit="10" d="

							M45.377,98.392c-0.953,

							0.55-2.513,0.552-3.467,

							0.005l-39.68-22.75	c-0.954-0.547-1.732-1.895-1.729-2.995l0.139-45.739c0.003-1.1,

							0.785-2.45,1.738-3l39.837-23c0.953-0.55,

							2.513-0.552,3.467-0.005

							l39.68,22.75c0.954,

							0.547,1.732,

							1.895,1.729,

							2.995l-0.139,

							45.739c-0.003,

							1.1-0.785,

							2.45-1.738,

							3L45.377,98.392z

							"></path>	

						</g>

						</svg>

					</div>

					<div class="set_password password_2" id="password_2">

						<div id="empty_2"></div>

						<svg id="line_2" width="50" height="80" viewBox="0 0 120 120" xmlns="http://www.w3.org/2000/svg" style="display: none;">

							<line x1="-40" y1="202" x2="150" y2="102" style="stroke:#008f97;stroke-width:4"></line>

						</svg>	

						<svg version="1.1" id="Layer_2" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="54.59px" height="99.306px" viewBox="0 0 87.59 99.306" enable-background="new 0 0 87.59 99.306" xml:space="preserve" style="display: none;">

						<g>

							<path stroke="#008f97" stroke-miterlimit="10" d="

							M45.377,98.392c-0.953,

							0.55-2.513,0.552-3.467,

							0.005l-39.68-22.75	c-0.954-0.547-1.732-1.895-1.729-2.995l0.139-45.739c0.003-1.1,

							0.785-2.45,1.738-3l39.837-23c0.953-0.55,

							2.513-0.552,3.467-0.005

							l39.68,22.75c0.954,

							0.547,1.732,

							1.895,1.729,

							2.995l-0.139,

							45.739c-0.003,

							1.1-0.785,

							2.45-1.738,

							3L45.377,98.392z

							"></path>

						</g>

						

						</svg>			

					</div> 

					<div class="set_password password_3" id="password_3">

						<div id="empty_3"></div>

						<svg id="line_3" width="30" height="80" viewBox="0 0 120 120" xmlns="http://www.w3.org/2000/svg" style="display: none;">

							<line x1="3" y1="-19" x2="1122" y2="583" style="stroke:#008f97;stroke-width:7"></line>

						</svg>	

						<svg version="1.1" id="Layer_3" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="54.59px" height="99.306px" viewBox="0 0 87.59 99.306" enable-background="new 0 0 87.59 99.306" xml:space="preserve" style="display: none;">

						<g>

							<path stroke="#008f97" stroke-miterlimit="10" d="

							M45.377,98.392c-0.953,

							0.55-2.513,0.552-3.467,

							0.005l-39.68-22.75	c-0.954-0.547-1.732-1.895-1.729-2.995l0.139-45.739c0.003-1.1,

							0.785-2.45,1.738-3l39.837-23c0.953-0.55,

							2.513-0.552,3.467-0.005

							l39.68,22.75c0.954,

							0.547,1.732,

							1.895,1.729,

							2.995l-0.139,

							45.739c-0.003,

							1.1-0.785,

							2.45-1.738,

							3L45.377,98.392z

							"></path>

						</g>

						</svg>					

					</div>

					<div class="set_password password_4" id="password_4">

						<div id="empty_4"></div>

						<svg id="line_4" width="30" height="80" viewBox="0 0 120 120" xmlns="http://www.w3.org/2000/svg" style="display: none;">

							<line x1="3" y1="-19" x2="1122" y2="583" style="stroke:#008f97;stroke-width:7"></line>

						</svg>

						<svg version="1.1" id="Layer_4" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="54.59px" height="99.306px" viewBox="0 0 87.59 99.306" enable-background="new 0 0 87.59 99.306" xml:space="preserve" style="display: none;">

						<g>

							<path stroke="#008f97" stroke-miterlimit="10" d="

							M45.377,98.392c-0.953,

							0.55-2.513,0.552-3.467,

							0.005l-39.68-22.75	c-0.954-0.547-1.732-1.895-1.729-2.995l0.139-45.739c0.003-1.1,

							0.785-2.45,1.738-3l39.837-23c0.953-0.55,

							2.513-0.552,3.467-0.005

							l39.68,22.75c0.954,

							0.547,1.732,

							1.895,1.729,

							2.995l-0.139,

							45.739c-0.003,

							1.1-0.785,

							2.45-1.738,

							3L45.377,98.392z

							"></path>

						</g>

						</svg>

				

					</div>

					<div class="set_password password_5" id="password_5">

						<div id="empty_5"></div>

						<svg id="line_5" width="50" height="80" viewBox="0 0 120 120" xmlns="http://www.w3.org/2000/svg" style="display: none;">

							<line x1="-40" y1="202" x2="150" y2="102" style="stroke:#008f97;stroke-width:4"></line>

						</svg>

						<svg version="1.1" id="Layer_5" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="54.59px" height="99.306px" viewBox="0 0 87.59 99.306" enable-background="new 0 0 87.59 99.306" xml:space="preserve" style="display: none;">

						<g>

							<path stroke="#008f97" stroke-miterlimit="10" d="

							M45.377,98.392c-0.953,

							0.55-2.513,0.552-3.467,

							0.005l-39.68-22.75	c-0.954-0.547-1.732-1.895-1.729-2.995l0.139-45.739c0.003-1.1,

							0.785-2.45,1.738-3l39.837-23c0.953-0.55,

							2.513-0.552,3.467-0.005

							l39.68,22.75c0.954,

							0.547,1.732,

							1.895,1.729,

							2.995l-0.139,

							45.739c-0.003,

							1.1-0.785,

							2.45-1.738,

							3L45.377,98.392z

							"></path>

						</g>

						</svg>

					</div>

					<div class="set_password password_6" id="password_6">

						<div id="empty_6"></div>

						<svg id="line_6" width="30" height="80" viewBox="0 0 120 120" xmlns="http://www.w3.org/2000/svg" style="display: none;">

							<line x1="3" y1="-19" x2="1122" y2="583" style="stroke:#008f97;stroke-width:7"></line>

						</svg>

						<svg version="1.1" id="Layer_6" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="54.59px" height="99.306px" viewBox="0 0 87.59 99.306" enable-background="new 0 0 87.59 99.306" xml:space="preserve" style="display: none;">

						<g>

							<path stroke="#008f97" stroke-miterlimit="10" fill="url(#empty_6)" d="

							M45.377,98.392c-0.953,

							0.55-2.513,0.552-3.467,

							0.005l-39.68-22.75	c-0.954-0.547-1.732-1.895-1.729-2.995l0.139-45.739c0.003-1.1,

							0.785-2.45,1.738-3l39.837-23c0.953-0.55,

							2.513-0.552,3.467-0.005

							l39.68,22.75c0.954,

							0.547,1.732,

							1.895,1.729,

							2.995l-0.139,

							45.739c-0.003,

							1.1-0.785,

							2.45-1.738,

							3L45.377,98.392z

							"></path>

						</g>

						</svg>

					</div>

					<div class="set_password password_7" id="password_7">

						<div id="empty_7"></div>

						<svg id="line_7" width="50" height="80" viewBox="0 0 120 120" xmlns="http://www.w3.org/2000/svg" style="display: none;">

							<line x1="-40" y1="202" x2="150" y2="102" style="stroke:#008f97;stroke-width:4"></line>

						</svg>

						<svg version="1.1" id="Layer_7" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="54.59px" height="99.306px" viewBox="0 0 87.59 99.306" enable-background="new 0 0 87.59 99.306" xml:space="preserve" style="display: none;">

						<g>

							<path stroke="#008f97" stroke-miterlimit="10" fill="url(#empty_7)" d="

							M45.377,98.392c-0.953,

							0.55-2.513,0.552-3.467,

							0.005l-39.68-22.75	c-0.954-0.547-1.732-1.895-1.729-2.995l0.139-45.739c0.003-1.1,

							0.785-2.45,1.738-3l39.837-23c0.953-0.55,

							2.513-0.552,3.467-0.005

							l39.68,22.75c0.954,

							0.547,1.732,

							1.895,1.729,

							2.995l-0.139,

							45.739c-0.003,

							1.1-0.785,

							2.45-1.738,

							3L45.377,98.392z

							"></path>

						</g>

						</svg>

					</div>

					

				</div>

				<div id="drawing"></div>

				<div class="overlay_div"></div>

			</div>
			<div id="sencecode"></div>
			<div id="email_bottom_sec">
				<button class="img_btn left_btn" onClick="genarateCode();"><img height="auto" src="<?php  echo base_url(); ?>assets/images/Get-access-code.png"></button>

				<input class="input_user" id="input_user" type="text" placeholder="Username">

				<button class="img_btn right_btn" id="sendCode"><img height="auto" src="<?php  echo base_url(); ?>assets/images/send-access-code.png"></button>
			</div>
		</div>

    	    

	</div>



<script>



$( document ).ready(function() {
var code = "";
//$('.clear_btn').hide();

//$('.checkbox_btn').hide();

$('#Layer_1').css('display','none');

$('#Layer_2').css('display','none');

$('#Layer_3').css('display','none');

$('#Layer_4').css('display','none');

$('#Layer_5').css('display','none');

$('#Layer_6').css('display','none');

$('#Layer_7').css('display','none');



$('#Layer_10').css('display','none');

$('#Layer_11').css('display','none');



$('#empty_8').css('display','none');

$('#empty_9').css('display','none');

$('#empty_10').css('display','none');



$('#line_2').css('display','none');

$('#line_3').css('display','none');

$('#line_4').css('display','none');

$('#line_5').css('display','none');

$('#line_6').css('display','none');

$('#line_7').css('display','none');



$('#img_close').css('display','none');

$('#checkbox').css('display','none');

$('#line_81').css('display','none');

$('#line_82').css('display','none');

$('#line_83').css('display','none');



});


$("#sendCode").click(function(){
var code1 = code;
var email = $('#input_user').val();
var base_url = "<?php echo base_url();?>";
	
	
		
	$.ajax({
			url:base_url+'Home/sendEmail',
			type:'POST',
			data:{'email':email,'code1':code1},
			success:function(data){
				alert(data);

			},
			error:function(data){
			alert(data);
			}
		});
	
});

function genarateCode()
{
var email = $('#input_user').val();

	if(!email)
		{
			alert("Please Enter Email");
			return false;
		}

for (div = 1; div <= 7; div++) 
{
	$('#empty_'+div).empty();
}
$('#Layer_1').css('display','none');

$('#Layer_2').css('display','none');

$('#Layer_3').css('display','none');

$('#Layer_4').css('display','none');

$('#Layer_5').css('display','none');

$('#Layer_6').css('display','none');

$('#Layer_7').css('display','none');

$('#Layer_10').css('display','none');

$('#Layer_11').css('display','none');



$('#empty_8').css('display','none');

$('#empty_9').css('display','none');

$('#empty_10').css('display','none');



$('#line_2').css('display','none');

$('#line_3').css('display','none');

$('#line_4').css('display','none');

$('#line_5').css('display','none');

$('#line_6').css('display','none');

$('#line_7').css('display','none');



$('#img_close').css('display','none');

$('#checkbox').css('display','none');

$('#line_81').css('display','none');

$('#line_82').css('display','none');

$('#line_83').css('display','none');


var base_url = "<?php echo base_url();?>";

	$.ajax({
		url:base_url+"Home/codeGenerator",
		type:'POST',
		data:{'email':email},
		success:function(data)
		{
		$('#sencecode').empty();
			//alert(data);
			$(".login_index").addClass("move");
			var res = data.split("-"); 		
			res.unshift('zero');
			
			
			
			for (div = 1; div <= 7; div++) {
			if(res[div] == 'Ear')
			{
				res[div]='ear';
			}
			else if(res[div] == 'Eye')
			{
				res[div]='eye';
			}
			else if(res[div] == 'Nose')
			{
				res[div]='Nose';
			}
			else if(res[div] == 'Hand')
			{
				res[div]='hand';
			}
			else if(res[div] == 'Lips')
			{
				res[div]='mouth';
			}
			
				//addSence('left_btn_'+div,res[div]);
				/*===================================*/
				if ($('#empty_'+div).is(':empty')){

			var img = document.createElement("IMG");

				img.src = base_url+"assets/images/"+res[div]+".png";

				img.setAttribute("id", "demoid"+div);

				document.getElementById('empty_'+div).appendChild(img);

				//$("#empty_1").delay(1500).fadeIn();

				if(div == 1){

					$("#empty_8").delay(3000).fadeIn();

					$('#img_close').css('display','block');

					$('#line_81').css('display','block');

					$('#Layer_10').css('display','block');

					//$('#empty_8').show();

				}

				if(div == 4){

					$("#empty_10").delay(3000).fadeIn();

					$('#line_82').css('display','block');

					//$('#empty_10').show();

				}

				if(div == 5){

					$("#empty_9").delay(3000).fadeIn();

					$('#checkbox').css('display','block');

					$('#line_83').css('display','block');

					$('#Layer_11').css('display','block');

					//$('#empty_9').show();

				}



				$('#Layer_'+div).css('display','block');

				$('#line_'+div).css('display','block');

	

		}
				/*=====================================*/
				
				
				
			}
			
			code = data;
			$('#sencecode').append(data);
			
		},
		error:function(data)
		{
			alert("error:" +data);
		}
	});
	
	//$(".add-box").load(base_url + "/home/dashboard/.add-box");
}




function addSence(id,image){

	for (i = 1; i <= 7; i++) {

		if ($('#empty_'+i).is(':empty')){

			var img = document.createElement("IMG");

				img.src = "images/"+image+".png";

				img.setAttribute("id", "demoid"+i);

				document.getElementById('empty_'+i).appendChild(img);

				//$("#empty_1").delay(1500).fadeIn();

				if(i == 1){

					$("#empty_8").delay(3000).fadeIn();

					$('#img_close').css('display','block');

					$('#line_81').css('display','block');

					$('#Layer_10').css('display','block');

					//$('#empty_8').show();

				}

				if(i == 4){

					$("#empty_10").delay(3000).fadeIn();

					$('#line_82').css('display','block');

					//$('#empty_10').show();

				}

				if(i == 5){

					$("#empty_9").delay(3000).fadeIn();

					$('#checkbox').css('display','block');

					$('#line_83').css('display','block');

					$('#Layer_11').css('display','block');

					//$('#empty_9').show();

				}



				$('#Layer_'+i).css('display','block');

				$('#line_'+i).css('display','block');

		break;

		}	

	}

}



function clearAll()

{

for (i = 1; i <= 7; i++) {

		$('#demoid'+i).remove();

		$('#Layer_'+i).css('display','none');

		$('#line_'+i).css('display','none');

		//$('#empty_'+i).css('display','none');

	   /*$('#password_'+i).empty();	*/

	}

	//$("#empty_8").delay(3000).fadeIn();

	$('#img_close').css('display','none');

	$('#checkbox').css('display','none');

	$('#line_81').css('display','none');

	$('#line_82').css('display','none');

	$('#line_83').css('display','none');

	$('#empty_10').css('display','none');

	$('#Layer_10').css('display','none');

	$('#Layer_11').css('display','none');

}







/*

$(".right_btn").click(function(){

	setTimeout(function(){

	   $(".overlay_div").addClass("info_active");

   }, 100);

});*/

</script>

</body></html>