<?php
class User_model extends CI_Model
{
    public function __construct() {
        parent::__construct();
    }
  // get the count of all count_categories
    public function count_user() {
    	$this->db->select('*');
    	$this->db->from('tbl_users');
		//$this->db->where(array('status'=>'1'));
    	$query = $this->db->get();
    	$num = $query->num_rows();
    	return  $num ;
    }
	 // add user 
 public function AddUser($arr) {
  	$arr['status'] = '1';
  	$arr['created_time'] =date('Y-m-d h:i:s');
	$arr['last_updated_time'] =date('Y-m-d h:i:s');
  	return  $this->db->insert('tbl_users', $arr);
}
// updating profile
public function UpdateProfile($arr) {
	if($arr['email']<>""){
		$this->db->where(array("email" => $arr['email']));
		unset($arr['email']);
	}
	$arr['last_updated_time'] =date('Y-m-d h:i:s');
	unset($arr['userid']);
	return  $this->db->update('tbl_users', $arr);
}
//checking email 
public function CheckEmail($arr) {
 	$this->db->select("*");
 	$this->db->from("tbl_users");
	$this->db->where(array('email'=>$arr['email'],'status'=>1));
   	$query=$this->db->get();
	//echo $this->db->last_query();
	return $query->num_rows();
 }   
   //### get user data by their id
   public function GetIndividualDetails($email) 
   {
	   	$this->db->select('*');
	   	$this->db->where(array('email'=>$email));
	   	$query = $this->db->get('tbl_users');
	   	 //echo $this->db->last_query();die;
	   	$result =$query->row_array();
	   	return $result;
   }
// addign a new ShowAllcategories
public function ShowAllUsers($limit, $start,$searchtext=array()) {
     	$this->db->select("*");
 	   	$this->db->from("tbl_users");
 		if($searchtext['title']<>''){
 			$this->db->or_like('email', $searchtext['title']);
  	  	}
 		$this->db->limit($limit, $start);
  	   	$this->db->order_by('id', 'ASC');
 	   	$query=$this->db->get();
 		// echo $this->db->last_query();die;
 	   	return $query->result_array();
    }
//### get user data by their id
public function GetIndividualUserData($userid){
	   	$this->db->select('*');
	   	$this->db->where(array('id'=>$userid));
	   	$query = $this->db->get('tbl_users');
	   	 //echo $this->db->last_query();die;
	   	$result =$query->row_array();
	   	return $result;
   }
   //### get user data by their id
public function EmailData($email){
	   	$this->db->select('*');
	   	$this->db->where(array('email'=>$email));
	   	$query = $this->db->get('tbl_users');
	   	//echo $this->db_last_query();die;
	   	$result =$query->row_array();
	   	return $result;
   }
 
 //####random number generator
public function random_generator(){
	$a=array
	('a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','u','r','s','t',
			'u','v','w','x','y','z','A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z','1','2','3','4','5','6','7','8','9','0','1','2','3','4','5','6','7','8','9','0');
	$length=array(12);
	shuffle($length);
	$n=$length[0];
	$str="";
	for($i=0;$i<$n;$i++)
	{
		shuffle($a);
		$str.=$a[0];
	}
   return $str;
}

 //####random number generator
public function new_random_generator(){
	$a=array
	('Ear','Eye','Nose','d','e','f','g','h','i','j','k','l','m','n','o','p','q','u','r','s','t',
			'u','v','w','x','y','z','A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z','1','2','3','4','5','6','7','8','9','0','1','2','3','4','5','6','7','8','9','0');
	$length=array(12);
	shuffle($length);
	$n=$length[0];
	$str="";
	for($i=0;$i<$n;$i++)
	{
		shuffle($a);
		$str.=$a[0];
	}
   return $str;
}

}
?>