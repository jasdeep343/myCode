<?php
class Admin_model extends CI_Model
{
    public function __construct() {
        parent::__construct();
    }
   //***** User login
   public function checkUserLogin($arr){
	   	$this->db->select('*');
	   	$this->db->where(array('email'=>$arr['email'],'password'=>md5($arr['password']),'status'=>'1' ));
	   	$query = $this->db->get('admin');
	   	$num = $query->num_rows();
	   	if($num=='0'){
	   		return $num;
	   	}else{
	   		$result =$query->row_array();
	   		return $result;
	   	}
   } 
   // updating updatelogintime  
   public function updatelogintime($arr) {
   	$this->db->where(array("email" => $arr['email']));
   	unset($arr['email']);
	unset($arr['password']);
	$arr['last_login_activity'] = date('Y-m-d h:i:s');
   	return $this->db->update('admin', $arr);
   }
   
   //### get user data by their id
   public function GetIndividualUserData($userid){
	   	$this->db->select('*');
	   	$this->db->where(array('id'=>$userid));
	   	$query = $this->db->get('admin');
	   	//echo $this->db_last_query();die;
	   	$result =$query->row_array();
	   	return $result;
   }
   // updating password while forget passworis done  
   public function update_profile($arr) {
   	$this->db->where(array("id" => $arr['id']));
	unset($arr['id']);
	$arr['password'] = md5($arr['password']);
   	return $this->db->update('admin', $arr);
   }
      //### get user data by their id
   public function GetAllNotifications()  {
	   	$this->db->select('*');
	   	$this->db->where(array('status'=>'1' ,'is_read'=>'0'));
	   	$query = $this->db->get('tbl_notification');
	   	//echo $this->db_last_query();die;
	   	$result =$query->result_array();
	   	return $result;
   }
 }
?>