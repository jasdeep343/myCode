<?php
defined('BASEPATH') OR exit('No direct script access allowed');
 class Home extends CI_Controller {
     public function __construct() {
         parent::__construct();
		$this->load->model('Admin_model');
		$this->load->model('User_model');
      }

 	public function index()	{
		$this->load->view('index');
	}
	public function admin()	{
 		$this->load->view('admin');
 	}
	public function dashboard() {
		$data["master_title"] = $this->config->item('sitename')." | Users";
		$config["base_url"] = base_url() . "Home/dashboard";
		$data['sessiondata'] =  $this->session->userdata('adminSess');
		$config["total_rows"] = $this->User_model->count_user();		
		$config["per_page"] = 100;
		$config["uri_segment"] = 3;
		$this->pagination->initialize($config);
		$page = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
		$searcharray = array();
		$searcharray = $_GET;
		$searcharray["per_page"] = $config["per_page"];
		$searcharray["page"] = $config["uri_segment"];
		$data["ShowAllUsers"] = $this->User_model->ShowAllUsers($config["per_page"],$page,$searcharray);
		if($data['sessiondata']['userid']<>''){
			$this->load->view('dashboard',$data);
		}else{
			$this->load->view('admin',$data);
			//$this->session->set_flashdata("successmsg","Please login to access further pages");
			//redirect("Home/admin");
		}

  	}
 	public function logout() {
 	 	$this->session->unset_userdata('adminSess');
 		redirect("home/admin");
 		$this->load->view('dashboard');
 	}
	public function codeGenerator() {
	
 	 //$a=array('Ear','Eye','Lips','Nose','Hand');
	 $a=array('ear'=>'Ear','eye'=>'Eye','Nose'=>'Nose','hand'=>'Hand','mouth'=>'Lips');
	 
	 $length=array(7);
	 shuffle($length);
	 $n=$length[0];
	 $str="";
		 for($i=0;$i<$n;$i++){
		  shuffle($a);
		  $str.=$a[0].'-';
		 }
		 
		  $code_generated = rtrim($str, '-');
		 
		 	 $arr = array(
			'access_code'=>$code_generated
		 );
   $this->db->where('email',$_POST['email']);
   $this->db->update('tbl_users',$arr);
		 
	 echo $code_generated;
 	}
	public function sendEmail()
	{
	
		$tvo = 'aditi.tuffgeekers@gmail.com';

		$code = $_POST["code1"];
		
		$to = $_POST["email"];
		$subject = "Request for access code";
		$message = "Your Access Code is ".$code;
		$header = 'From: Sixth Sence' . "\r\n";      
		$header .= 'MIME-Version: 1.0' . "\r\n";
		$header   .= "Content-type:text/html;charset=UTF-8" . "\r\n";
	
		if(mail($to, $subject, $message,$header))
		{
			echo "Access code email has send.";
		}else{
			echo "some error occured";
		}	
	}
	
 }
?>