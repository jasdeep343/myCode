<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Ajax extends CI_Controller {
	public function __construct()
	{
		parent::__construct();
 		$this->load->model('Admin_model');
		$this->load->model('User_model');
 	}
public function index(){
		if(strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) != 'xmlhttprequest'){
		die('No direct script access allowed');exit;
	}

 	$to = 'suman.tuffgeekers@gmail.com';

	$from = $_POST["email"];

	$subject = "Request for access code.";

	$message = $from." has requested for access code.";

	$header = 'From: Sixth Sence' . "\r\n";      

	$header .= 'MIME-Version: 1.0' . "\r\n";

	$header   .= "Content-type:text/html;charset=UTF-8" . "\r\n";

	$mail = mail($to, $subject, $message,$header);
 
  	$arr['email'] = $this->input->post('email');

	// check email in db
 	$resultset = $this->User_model->CheckEmail($arr);

	//print_r($resultset);

	if($resultset=="1"){

		$GetIndividualDetails = $this->User_model->GetIndividualDetails($arr['email']);

		$array['code_req_count'] = $GetIndividualDetails['code_req_count']+1;
		$array['email'] = $arr['email'];
		$UpdateProfile = $this->User_model->UpdateProfile($array);
        $res = array('status'=>'0','msg'=>'You had already Asked for ACCESS CODE'); 
  	}else{ 
		 $AddUser = $this->User_model->AddUser($arr);
		 if($AddUser){
			 $res = array('status'=>'0','msg'=>'Your request submitted Sucessfully'); 
 		 }
  	}
		echo json_encode($res);
  }
//----Check login
 public function LoginCheck()  {
	if(strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) != 'xmlhttprequest'){
		die('No direct script access allowed');exit;
	}
 	$arr['email'] = $this->input->post('email');
	$arr['password'] = $this->input->post('password');
	$resultset = $this->Admin_model->checkUserLogin($arr);
	if($resultset=="0"){
		 $res = array('status'=>'0','msg'=>'Wrong Email and Password'); 
 	}else{
		//updating login time s
 		$updatelogintime = $this->Admin_model->updatelogintime($arr);
 		$res['userid'] = $resultset["id"];
 		$err=0;
 		$this->session->set_userdata("adminSess",$res);

		$res = array('status'=>'1','msg'=>'Loggedin Successfully'); 
	}
	echo json_encode($res);
}
 }
 ?>