
$( document ).ready(function() {

$('#Layer_1').css('display','none');
$('#Layer_2').css('display','none');
$('#Layer_3').css('display','none');
$('#Layer_4').css('display','none');
$('#Layer_5').css('display','none');
$('#Layer_6').css('display','none');
$('#Layer_7').css('display','none');

$('#Layer_10').css('display','none');
$('#Layer_11').css('display','none');

$('#empty_8').css('display','none');
$('#empty_9').css('display','none');
$('#empty_10').css('display','none');

$('#line_2').css('display','none');
$('#line_3').css('display','none');
$('#line_4').css('display','none');
$('#line_5').css('display','none');
$('#line_6').css('display','none');
$('#line_7').css('display','none');

$('#img_close').css('display','none');
$('#checkbox').css('display','none');
$('#line_81').css('display','none');
$('#line_82').css('display','none');
$('#line_83').css('display','none');

});
function accessCode()
{
	var email = $('#user_email').val();
	var mailformat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;

	if(email==""){
		alert("Please Enter an Email first to get access code");
		$("#user_email").focus();
	}else if(!mailformat.test(email)){
			alert("Please enter a valid email address");
 			$("#user_email").focus();
 	}else{
 		$.ajax({
			url:BASE_URL+'Ajax',
			type:'POST',
			data:{"email":email},
			success:function(rep){
				jsonResult = JSON.parse(rep);
				alert(jsonResult.msg);
 			},
			error:function(data){
				alert("error: "+data);
			}
		
		});
	}
}

function addSence(id,image){

	for (i = 1; i <= 7; i++) {
		if ($('#empty_'+i).is(':empty')){
			var img = document.createElement("IMG");
				img.src = "images/"+image+".png";
				img.setAttribute("id", "demoid"+i);
				document.getElementById('empty_'+i).appendChild(img);
				//$("#empty_1").delay(1500).fadeIn();
				if(i == 1){
					$("#empty_8").delay(3000).fadeIn();
					$('#img_close').css('display','block');
					$('#line_81').css('display','block');
					$('#Layer_10').css('display','block');
					//$('#empty_8').show();
				}
				if(i == 4){
					$("#empty_10").delay(3000).fadeIn();
					$('#line_82').css('display','block');
					//$('#empty_10').show();
				}
				if(i == 5){
					$("#empty_9").delay(3000).fadeIn();
					$('#checkbox').css('display','block');
					$('#line_83').css('display','block');
					$('#Layer_11').css('display','block');
					//$('#empty_9').show();
				}

				$('#Layer_'+i).css('display','block');
				$('#line_'+i).css('display','block');
		break;
		}	
	}
}

function clearAll()
{
	for (i = 1; i <= 7; i++) {
		$('#demoid'+i).remove();
		$('#Layer_'+i).css('display','none');
		$('#line_'+i).css('display','none');	
	}	
	
	$('#img_close').css('display','none');
	$('#checkbox').css('display','none');
	$('#line_81').css('display','none');
	$('#line_82').css('display','none');
	$('#line_83').css('display','none');
	$('#empty_10').css('display','none');
	$('#Layer_10').css('display','none');
	$('#Layer_11').css('display','none');
}



$(".img_btn.right_btn").click(function(){
	setTimeout(function(){
	   $(".login_index").addClass("move");
   });
});
//for admibn login validations 
 function AdminLogin() {
	var AdminEmail =  $.trim($('#AdminEmail').val());
	var AdminPassword =  $.trim($('#AdminPassword').val());
	if(AdminEmail ==""){
		$("#AdminError").html("Please Enter Email");
		$("#AdminEmail").focus();
	}else if(AdminPassword ==""){
		$("#AdminError").html("Please Enter Password");
		$("#AdminPassword").focus();
	  }else{
				$.ajax({  
				url: BASE_URL+"Ajax/LoginCheck", 
				type: "POST", 
				data: {"email" : AdminEmail,"password":AdminPassword},
				success: function(rep) {
 				    jsonResult = JSON.parse(rep);
					if(jsonResult.status == '1'){
						window.location.href = BASE_URL+"home/dashboard";
					}else{
						$('#AdminError').html(jsonResult.msg);
					}
				}
			})
    	}
}
 